const fs = require('fs');

const orders = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_orders.json', 'utf8'));
const products = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_products.json', 'utf8'));
const customers = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_customers.json', 'utf8'));
const regions = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_regions.json', 'utf8'));

// Customer lookup
const custMap = {};
customers.forEach(c => { custMap[c.CustomerID] = c; });

// Product lookup
const prodMap = {};
products.forEach(p => { prodMap[p.ProductID] = p; });

// Metrics
let totalRevenue = 0;
let totalDiscount = 0;
let totalShipping = 0;
let totalQty = 0;
let deliveredOrders = 0;
let deliveredRevenue = 0;
let totalLateDays = 0;
let lateOrdersCount = 0;
let deliveredWithDaysCount = 0;
let totalDeliveryDays = 0;

const customerSegmentStats = {};
const brandStats = {};
const monthlyTrends = {};
const cityStats = {};
const stateStats = {};
const subcatStats = {};
const quarterStats = {};
const dowStats = { 'Sunday': 0, 'Monday': 0, 'Tuesday': 0, 'Wednesday': 0, 'Thursday': 0, 'Friday': 0, 'Saturday': 0 };

orders.forEach(o => {
  totalRevenue += o.salesINR;
  totalDiscount += o.discINR;
  totalShipping += o.shipFee;
  totalQty += o.qty;

  if (o.status === 'Delivered') {
    deliveredOrders++;
    deliveredRevenue += o.salesINR;
    if (o.deliveryDays !== null && !isNaN(o.deliveryDays)) {
      deliveredWithDaysCount++;
      totalDeliveryDays += o.deliveryDays;
    }
    if (o.lateDays > 0) {
      lateOrdersCount++;
      totalLateDays += o.lateDays;
    }
  }

  // Customer segment
  const cust = custMap[o.custId] || { CustomerSegment: 'Unknown', CustomerName: 'Guest' };
  const seg = cust.CustomerSegment || 'Standard';
  if (!customerSegmentStats[seg]) {
    customerSegmentStats[seg] = { segment: seg, revenue: 0, orders: 0, customers: new Set() };
  }
  customerSegmentStats[seg].revenue += o.salesINR;
  customerSegmentStats[seg].orders += 1;
  customerSegmentStats[seg].customers.add(o.custId);

  // Brand
  const prd = prodMap[o.prodId] || { Brand: 'Other' };
  const brand = prd.Brand || 'Other';
  if (!brandStats[brand]) {
    brandStats[brand] = { brand, revenue: 0, orders: 0, qty: 0 };
  }
  brandStats[brand].revenue += o.salesINR;
  brandStats[brand].orders += 1;
  brandStats[brand].qty += o.qty;

  // Monthly trends
  const m = `${o.year}-${String(o.monthNum).padStart(2, '0')}`;
  if (!monthlyTrends[m]) {
    monthlyTrends[m] = { month: m, monthName: o.month, revenue: 0, orders: 0, qty: 0, discount: 0 };
  }
  monthlyTrends[m].revenue += o.salesINR;
  monthlyTrends[m].orders += 1;
  monthlyTrends[m].qty += o.qty;
  monthlyTrends[m].discount += o.discINR;

  // Quarter
  if (!quarterStats[o.quarter]) {
    quarterStats[o.quarter] = { quarter: o.quarter, revenue: 0, orders: 0 };
  }
  quarterStats[o.quarter].revenue += o.salesINR;
  quarterStats[o.quarter].orders += 1;

  // City & State
  if (!cityStats[o.city]) {
    cityStats[o.city] = { city: o.city, state: o.state, region: o.region, revenue: 0, orders: 0 };
  }
  cityStats[o.city].revenue += o.salesINR;
  cityStats[o.city].orders += 1;

  if (!stateStats[o.state]) {
    stateStats[o.state] = { state: o.state, region: o.region, revenue: 0, orders: 0 };
  }
  stateStats[o.state].revenue += o.salesINR;
  stateStats[o.state].orders += 1;

  // Subcategory
  if (!subcatStats[o.subcategory]) {
    subcatStats[o.subcategory] = { subcat: o.subcategory, category: o.category, revenue: 0, orders: 0 };
  }
  subcatStats[o.subcategory].revenue += o.salesINR;
  subcatStats[o.subcategory].orders += 1;

  // Day of week
  if (o.date) {
    const d = new Date(o.date + 'T00:00:00');
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = days[d.getDay()];
    if (dayName) {
      dowStats[dayName] = (dowStats[dayName] || 0) + o.salesINR;
    }
  }
});

// Format segment stats
const segmentSummary = Object.values(customerSegmentStats).map(s => ({
  segment: s.segment,
  revenue: Math.round(s.revenue),
  orders: s.orders,
  uniqueCustomers: s.customers.size,
  avgSpendPerCustomer: Math.round(s.revenue / s.customers.size),
  aov: Math.round(s.revenue / s.orders)
})).sort((a,b) => b.revenue - a.revenue);

const topBrands = Object.values(brandStats).map(b => ({
  brand: b.brand,
  revenue: Math.round(b.revenue),
  orders: b.orders,
  qty: b.qty
})).sort((a,b) => b.revenue - a.revenue);

const topCities = Object.values(cityStats).map(c => ({
  city: c.city,
  state: c.state,
  region: c.region,
  revenue: Math.round(c.revenue),
  orders: c.orders
})).sort((a,b) => b.revenue - a.revenue);

const topStates = Object.values(stateStats).map(s => ({
  state: s.state,
  region: s.region,
  revenue: Math.round(s.revenue),
  orders: s.orders
})).sort((a,b) => b.revenue - a.revenue);

const topSubcategories = Object.values(subcatStats).map(s => ({
  subcategory: s.subcat,
  category: s.category,
  revenue: Math.round(s.revenue),
  orders: s.orders
})).sort((a,b) => b.revenue - a.revenue);

const avgDeliveryDays = deliveredWithDaysCount > 0 ? (totalDeliveryDays / deliveredWithDaysCount).toFixed(2) : 0;
const onTimeDeliveryRate = deliveredOrders > 0 ? (((deliveredOrders - lateOrdersCount) / deliveredOrders) * 100).toFixed(2) : 0;
const avgLateDaysForDelayed = lateOrdersCount > 0 ? (totalLateDays / lateOrdersCount).toFixed(2) : 0;

const detailedAnalysis = {
  kpis: {
    totalRevenue: Math.round(totalRevenue),
    totalOrders: orders.length,
    deliveredOrders,
    deliveredRevenue: Math.round(deliveredRevenue),
    totalQty,
    totalDiscount: Math.round(totalDiscount),
    totalShipping: Math.round(totalShipping),
    avgOrderValue: Math.round(totalRevenue / orders.length),
    avgDeliveryDays: parseFloat(avgDeliveryDays),
    onTimeDeliveryRate: parseFloat(onTimeDeliveryRate),
    lateOrdersCount,
    avgLateDaysForDelayed: parseFloat(avgLateDaysForDelayed)
  },
  segmentSummary,
  topBrands,
  monthlyTrends: Object.values(monthlyTrends).sort((a,b) => a.month.localeCompare(b.month)),
  quarterStats: Object.values(quarterStats).sort((a,b) => a.quarter.localeCompare(b.quarter)),
  topCities: topCities.slice(0, 15),
  topStates: topStates.slice(0, 15),
  topSubcategories: topSubcategories.slice(0, 15),
  dowStats
};

console.log('Detailed Analysis:');
console.log(JSON.stringify(detailedAnalysis.kpis, null, 2));
console.log('Customer Segments:', detailedAnalysis.segmentSummary);
console.log('Top 5 Brands:', detailedAnalysis.topBrands.slice(0, 5));
console.log('Quarter Stats:', detailedAnalysis.quarterStats);

fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\deep_analysis.json', JSON.stringify(detailedAnalysis, null, 2));
