const fs = require('fs');
const path = require('path');

const unpackedDir = 'C:\\Users\\PC\\.gemini\\antigravity\\scratch\\xlsx_unpacked\\xl';

// 1. Parse sharedStrings.xml
function parseSharedStrings() {
  const ssXml = fs.readFileSync(path.join(unpackedDir, 'sharedStrings.xml'), 'utf8');
  const strings = [];
  // Match each <si>...</si>
  const siRegex = /<si>(.*?)<\/si>/gs;
  let match;
  while ((match = siRegex.exec(ssXml)) !== null) {
    const siContent = match[1];
    // extract all <t>...</t> or <t xml:space="preserve">...</t>
    const tRegex = /<t[^>]*>(.*?)<\/t>/gs;
    let tMatch;
    let text = '';
    while ((tMatch = tRegex.exec(siContent)) !== null) {
      text += tMatch[1];
    }
    // decode basic xml entities
    text = text.replace(/&amp;/g, '&')
               .replace(/&lt;/g, '<')
               .replace(/&gt;/g, '>')
               .replace(/&quot;/g, '"')
               .replace(/&apos;/g, "'");
    strings.push(text);
  }
  return strings;
}

const sharedStrings = parseSharedStrings();
console.log('Parsed shared strings count:', sharedStrings.length);

function colIndex(colStr) {
  let num = 0;
  for (let i = 0; i < colStr.length; i++) {
    num = num * 26 + (colStr.charCodeAt(i) - 64);
  }
  return num - 1; // 0-based
}

function parseSheet(sheetFileName) {
  const xml = fs.readFileSync(path.join(unpackedDir, 'worksheets', sheetFileName), 'utf8');
  const rows = [];
  const rowRegex = /<row\s+r="(\d+)"[^>]*>(.*?)<\/row>/gs;
  let rMatch;
  while ((rMatch = rowRegex.exec(xml)) !== null) {
    const rowNum = parseInt(rMatch[1]);
    const rowContent = rMatch[2];
    const rowData = {};

    const cellRegex = /<c\s+r="([A-Z]+)\d+"(?:[^>]*?t="([a-z]+)")?[^>]*>(?:<v>(.*?)<\/v>)?<\/c>/gs;
    let cMatch;
    while ((cMatch = cellRegex.exec(rowContent)) !== null) {
      const colLetter = cMatch[1];
      const type = cMatch[2];
      const val = cMatch[3];

      let cellValue = '';
      if (val !== undefined && val !== null) {
        if (type === 's') {
          cellValue = sharedStrings[parseInt(val)] || '';
        } else {
          cellValue = val;
        }
      }
      rowData[colLetter] = cellValue;
    }
    rows.push({ rowNum, data: rowData });
  }
  return rows;
}

// Parse Products
const productsRows = parseSheet('sheet2.xml');
const productHeaders = productsRows[0].data;
const products = [];
for (let i = 1; i < productsRows.length; i++) {
  const d = productsRows[i].data;
  products.push({
    ProductID: d.A,
    ProductName: d.B,
    Category: d.C,
    Subcategory: d.D,
    UnitPriceINR: parseFloat(d.E) || 0,
    Brand: d.F
  });
}
console.log('Products parsed:', products.length);

// Parse Regions
const regionsRows = parseSheet('sheet5.xml');
const regions = [];
for (let i = 1; i < regionsRows.length; i++) {
  const d = regionsRows[i].data;
  regions.push({
    Region: d.A,
    City: d.B,
    State: d.C,
    Country: d.D,
    Latitude: parseFloat(d.E) || 0,
    Longitude: parseFloat(d.F) || 0
  });
}
console.log('Regions parsed:', regions.length);

// Parse Customers
const customerRows = parseSheet('sheet3.xml');
const customers = [];
for (let i = 1; i < customerRows.length; i++) {
  const d = customerRows[i].data;
  customers.push({
    CustomerID: d.A,
    CustomerName: d.B,
    CustomerSegment: d.C,
    CustomerCity: d.D,
    SignupDate: d.E,
    LoyaltyPoints: parseFloat(d.F) || 0
  });
}
console.log('Customers parsed:', customers.length);

// Parse Orders
const ordersRows = parseSheet('sheet1.xml');
console.log('Orders raw rows:', ordersRows.length);

function excelDateToISO(serial) {
  if (!serial || isNaN(serial)) return '';
  const num = parseFloat(serial);
  if (num <= 0) return '';
  const utc_days = Math.floor(num - 25569);
  const utc_value = utc_days * 86400;
  const date_info = new Date(utc_value * 1000);
  return date_info.toISOString().split('T')[0];
}

const orders = [];
for (let i = 1; i < ordersRows.length; i++) {
  const d = ordersRows[i].data;
  const orderDate = excelDateToISO(d.B);
  const promisedDate = excelDateToISO(d.S);
  const deliveryDate = excelDateToISO(d.T);

  orders.push({
    id: d.A,
    date: orderDate,
    custId: d.C,
    prodId: d.D,
    product: d.E,
    category: d.F,
    subcategory: d.G,
    qty: parseInt(d.H) || 0,
    unitPrice: parseFloat(d.I) || 0,
    discPct: parseFloat(d.J) || 0,
    discINR: parseFloat(d.K) || 0,
    shipFee: parseFloat(d.L) || 0,
    salesINR: parseFloat(d.M) || 0,
    payment: d.N,
    status: d.O,
    region: d.P,
    city: d.Q,
    state: d.R,
    promisedDate: promisedDate,
    deliveryDate: deliveryDate,
    deliveryDays: d.U ? parseInt(d.U) : null,
    lateDays: d.V ? parseInt(d.V) : 0,
    year: d.W ? parseInt(d.W) : 2025,
    monthNum: d.X ? parseInt(d.X) : 0,
    month: d.Y,
    quarter: d.Z
  });
}
console.log('Orders successfully processed:', orders.length);

// Compute Overall Summary Stats
let totalSales = 0;
let totalOrders = orders.length;
let totalQty = 0;
let totalDiscount = 0;
let totalShipping = 0;
const statusCounts = {};
const categorySales = {};
const categoryOrders = {};
const regionSales = {};
const regionOrders = {};
const paymentSales = {};
const paymentOrders = {};
const monthlySales = {};
const productSales = {};

orders.forEach(o => {
  totalSales += o.salesINR;
  totalQty += o.qty;
  totalDiscount += o.discINR;
  totalShipping += o.shipFee;

  statusCounts[o.status] = (statusCounts[o.status] || 0) + 1;
  categorySales[o.category] = (categorySales[o.category] || 0) + o.salesINR;
  categoryOrders[o.category] = (categoryOrders[o.category] || 0) + 1;

  regionSales[o.region] = (regionSales[o.region] || 0) + o.salesINR;
  regionOrders[o.region] = (regionOrders[o.region] || 0) + 1;

  paymentSales[o.payment] = (paymentSales[o.payment] || 0) + o.salesINR;
  paymentOrders[o.payment] = (paymentOrders[o.payment] || 0) + 1;

  const mKey = `${o.year}-${String(o.monthNum).padStart(2, '0')}`;
  monthlySales[mKey] = (monthlySales[mKey] || 0) + o.salesINR;

  if (!productSales[o.product]) {
    productSales[o.product] = { product: o.product, category: o.category, sales: 0, qty: 0, orders: 0 };
  }
  productSales[o.product].sales += o.salesINR;
  productSales[o.product].qty += o.qty;
  productSales[o.product].orders += 1;
});

const summary = {
  totalRevenueINR: Math.round(totalSales * 100) / 100,
  totalOrders,
  totalQty,
  totalDiscountINR: Math.round(totalDiscount * 100) / 100,
  totalShippingINR: Math.round(totalShipping * 100) / 100,
  avgOrderValueINR: Math.round((totalSales / totalOrders) * 100) / 100,
  statusCounts,
  categorySales,
  regionSales,
  paymentSales,
  monthlySales,
  topProducts: Object.values(productSales).sort((a,b) => b.sales - a.sales).slice(0, 10)
};

console.log('SUMMARY METRICS:');
console.log('Total Revenue:', summary.totalRevenueINR);
console.log('Total Orders:', summary.totalOrders);
console.log('Avg Order Value:', summary.avgOrderValueINR);
console.log('Status Breakdown:', summary.statusCounts);
console.log('Category Sales:', summary.categorySales);
console.log('Region Sales:', summary.regionSales);
console.log('Payment Sales:', summary.paymentSales);

// Save outputs
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_summary.json', JSON.stringify(summary, null, 2));
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_orders.json', JSON.stringify(orders));
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_products.json', JSON.stringify(products));
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_regions.json', JSON.stringify(regions));
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_customers.json', JSON.stringify(customers));
console.log('All files saved successfully to scratch!');
