const fs = require('fs');
const path = require('path');

const orders = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_orders.json', 'utf8'));
const custs = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_customers.json', 'utf8'));
const deep = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\deep_analysis.json', 'utf8'));

const custMap = {};
custs.forEach(c => {
  custMap[c.CustomerID] = {
    name: c.CustomerName || 'Customer',
    segment: c.CustomerSegment || 'Standard',
    points: c.LoyaltyPoints || 0
  };
});

// Compress orders into lightweight tuples:
// [id, date, product, category, subcat, qty, price, discINR, shipFee, sales, payment, status, region, city, state, delDays, lateDays, qtr, mNum, custSeg, custName]
const compactOrders = orders.map(o => {
  const c = custMap[o.custId] || { name: 'Customer', segment: 'Standard' };
  return [
    o.id,
    o.date,
    o.product,
    o.category,
    o.subcategory,
    o.qty,
    o.unitPrice,
    Math.round(o.discINR * 10) / 10,
    o.shipFee,
    Math.round(o.salesINR * 10) / 10,
    o.payment,
    o.status,
    o.region,
    o.city,
    o.state,
    o.deliveryDays !== null ? o.deliveryDays : -1,
    o.lateDays,
    o.quarter,
    o.monthNum,
    c.segment,
    c.name
  ];
});

console.log('Total compact orders:', compactOrders.length);

const htmlTemplate = `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Amazon India | Executive Sales & Operations Analytics Dashboard</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <!-- Google Fonts Inter & Outfit -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            amz: {
              dark: '#0B0F19',
              slate: '#111827',
              card: '#161F30',
              cardHover: '#1C273C',
              border: '#23324A',
              orange: '#FF9900',
              orangeHover: '#E68A00',
              amberGlow: '#FFA41C',
              cyan: '#00E5FF',
              cyanGlow: '#00B4D8',
              emerald: '#10B981',
              emeraldGlow: '#00E676',
              rose: '#F43F5E',
              purple: '#A855F7',
              blue: '#2563EB'
            }
          },
          fontFamily: {
            sans: ['"Plus Jakarta Sans"', 'sans-serif'],
            display: ['Outfit', 'sans-serif']
          },
          boxShadow: {
            'glow-amber': '0 0 25px -3px rgba(255, 153, 0, 0.35)',
            'glow-cyan': '0 0 25px -3px rgba(0, 229, 255, 0.35)',
            'glow-emerald': '0 0 25px -3px rgba(16, 185, 129, 0.35)',
            'glow-purple': '0 0 25px -3px rgba(168, 85, 247, 0.35)',
            'glow-rose': '0 0 25px -3px rgba(244, 63, 94, 0.35)',
            'glow-card': '0 8px 32px 0 rgba(0, 0, 0, 0.45)'
          }
        }
      }
    }
  </script>

  <style>
    body {
      background-color: #080C14;
      color: #E2E8F0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      overflow-x: hidden;
    }
    
    /* Background Ambient Glowing Orbs */
    .ambient-glow-1 {
      position: fixed;
      top: -100px;
      right: -100px;
      width: 550px;
      height: 550px;
      background: radial-gradient(circle, rgba(255, 153, 0, 0.12) 0%, rgba(255, 153, 0, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(40px);
    }
    .ambient-glow-2 {
      position: fixed;
      bottom: -150px;
      left: 10%;
      width: 650px;
      height: 650px;
      background: radial-gradient(circle, rgba(0, 229, 255, 0.08) 0%, rgba(0, 229, 255, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(50px);
    }
    .ambient-glow-3 {
      position: fixed;
      top: 40%;
      right: 25%;
      width: 450px;
      height: 450px;
      background: radial-gradient(circle, rgba(168, 85, 247, 0.07) 0%, rgba(168, 85, 247, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(60px);
    }

    /* Glass Panels */
    .glass-panel {
      background: rgba(20, 28, 44, 0.72);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(43, 62, 92, 0.65);
      border-radius: 1rem;
      transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .glass-panel:hover {
      border-color: rgba(65, 92, 133, 0.85);
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.6);
    }

    /* Glowing borders */
    .glow-border-amber {
      border: 1px solid rgba(255, 153, 0, 0.4);
      box-shadow: inset 0 0 15px rgba(255, 153, 0, 0.08), 0 0 20px rgba(255, 153, 0, 0.15);
    }
    .glow-border-cyan {
      border: 1px solid rgba(0, 229, 255, 0.4);
      box-shadow: inset 0 0 15px rgba(0, 229, 255, 0.08), 0 0 20px rgba(0, 229, 255, 0.15);
    }
    .glow-border-emerald {
      border: 1px solid rgba(16, 185, 129, 0.4);
      box-shadow: inset 0 0 15px rgba(16, 185, 129, 0.08), 0 0 20px rgba(16, 185, 129, 0.15);
    }
    .glow-border-purple {
      border: 1px solid rgba(168, 85, 247, 0.4);
      box-shadow: inset 0 0 15px rgba(168, 85, 247, 0.08), 0 0 20px rgba(168, 85, 247, 0.15);
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    ::-webkit-scrollbar-track {
      background: #0B0F19;
    }
    ::-webkit-scrollbar-thumb {
      background: #23324A;
      border-radius: 9999px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: #FF9900;
    }

    /* Pulse animation */
    @keyframes subtlePulse {
      0%, 100% { opacity: 0.8; transform: scale(1); }
      50% { opacity: 1; transform: scale(1.02); }
    }
    .live-pulse {
      animation: subtlePulse 2.5s infinite ease-in-out;
    }
  </style>
</head>
<body class="min-h-screen relative selection:bg-amz-orange selection:text-black">

  <!-- Ambient Glowing Mesh Backdrop -->
  <div class="ambient-glow-1"></div>
  <div class="ambient-glow-2"></div>
  <div class="ambient-glow-3"></div>

  <!-- Main Container -->
  <div class="relative z-10 max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-6">

    <!-- Top Navigation / Brand Bar -->
    <header class="glass-panel p-4 lg:p-5 flex flex-wrap items-center justify-between gap-4 border-b border-amz-border">
      <div class="flex items-center gap-4">
        <!-- Amazon Logo Badge -->
        <div class="relative flex items-center justify-center bg-gradient-to-br from-[#1E293B] to-[#0F172A] p-2.5 px-4 rounded-xl border border-amz-border shadow-md">
          <div class="flex items-center gap-2">
            <span class="font-display font-black text-2xl tracking-tight text-white flex items-center">
              amazon<span class="text-amz-orange text-3xl leading-none">.in</span>
            </span>
            <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-amz-orange/20 text-amz-orange border border-amz-orange/40 uppercase tracking-wider ml-1">Seller Central</span>
          </div>
        </div>
        
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-xl lg:text-2xl font-display font-bold text-white tracking-wide flex items-center gap-2">
              Sales & Operational Intelligence
              <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>Live Fiscal 2025</span>
              </span>
            </h1>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">5,000 Verified Transactions across 35 Hubs • Advanced Interactive Telemetry</p>
        </div>
      </div>

      <!-- Header Action Controls -->
      <div class="flex items-center flex-wrap gap-2.5">
        <!-- Currency View Toggle -->
        <div class="inline-flex rounded-lg bg-slate-900/80 p-1 border border-amz-border text-xs">
          <button id="currBtnCrore" onclick="setCurrencyMode('crore')" class="px-3 py-1.5 rounded-md font-semibold transition text-slate-300 hover:text-white bg-slate-800 text-amz-orange">₹ Crores / Lakhs</button>
          <button id="currBtnFull" onclick="setCurrencyMode('full')" class="px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white">Full INR</button>
        </div>

        <!-- Quick Action: Analytical Report Modal -->
        <button onclick="toggleModal('analyticsReportModal')" class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600/30 to-blue-600/30 hover:from-purple-600/50 hover:to-blue-600/50 text-purple-200 border border-purple-500/40 text-xs font-semibold shadow-glow-purple transition">
          <svg class="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          Executive Analysis
        </button>

        <!-- Quick Action: Export CSV -->
        <button onclick="exportFilteredCSV()" class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amz-orange to-amber-600 hover:from-amber-500 hover:to-amber-700 text-black text-xs font-bold shadow-glow-amber transition">
          <svg class="w-4 h-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
          Export Dataset
        </button>

        <!-- Reset All Filters -->
        <button onclick="resetAllFilters()" title="Reset All Filters" class="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-amz-border transition">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
        </button>
      </div>
    </header>

    <!-- Comprehensive Interactive Filter Bar -->
    <section class="glass-panel p-4 lg:p-5 space-y-4">
      <div class="flex items-center justify-between flex-wrap gap-2 border-b border-slate-700/60 pb-3">
        <div class="flex items-center gap-2">
          <svg class="w-4 h-4 text-amz-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/></svg>
          <span class="text-sm font-semibold uppercase tracking-wider text-slate-200">Interactive Filter Engine</span>
          <span id="activeFilterBadge" class="text-xs px-2 py-0.5 rounded-full bg-amz-cyan/20 text-amz-cyan border border-amz-cyan/40 font-mono">All 5,000 Orders</span>
        </div>

        <!-- Quick Preset Pills -->
        <div class="flex items-center gap-1.5 flex-wrap text-xs">
          <span class="text-slate-400 mr-1 hidden sm:inline">Quick Presets:</span>
          <button onclick="applyPreset('all')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-white border border-slate-700 active-preset">All</button>
          <button onclick="applyPreset('topFlagships')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-amz-orange border border-slate-700">🔥 Top Flagships</button>
          <button onclick="applyPreset('prime')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-amz-cyan border border-slate-700">⭐ Prime Members</button>
          <button onclick="applyPreset('delayed')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-amz-rose border border-slate-700">⚠️ Delayed SLA</button>
          <button onclick="applyPreset('highValue')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-amz-emerald border border-slate-700">💎 High Ticket (₹20k+)</button>
          <button onclick="applyPreset('upi')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-purple-400 border border-slate-700">⚡ UPI Payments</button>
        </div>
      </div>

      <!-- Controls Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <!-- Live Search -->
        <div class="col-span-2 sm:col-span-3 md:col-span-2">
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Search Anything</label>
          <div class="relative">
            <input type="text" id="searchInput" placeholder="Order ID, Product, City, State..." oninput="debounceFilter()" 
              class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-3 py-2 pl-8 border border-slate-700 focus:outline-none focus:border-amz-orange focus:ring-1 focus:ring-amz-orange transition placeholder:text-slate-500">
            <svg class="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </div>
        </div>

        <!-- Quarter Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Quarter</label>
          <select id="quarterFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Quarters</option>
            <option value="Q1">Q1 (Jan-Mar)</option>
            <option value="Q2">Q2 (Apr-Jun)</option>
            <option value="Q3">Q3 (Jul-Sep)</option>
            <option value="Q4">Q4 (Oct-Dec)</option>
          </select>
        </div>

        <!-- Month Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Month</label>
          <select id="monthFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Months</option>
            <option value="1">Jan (₹27.4L)</option>
            <option value="2">Feb (₹43.1L)</option>
            <option value="3">Mar (₹31.5L)</option>
            <option value="4">Apr (₹34.7L)</option>
            <option value="5">May (₹33.2L)</option>
            <option value="6">Jun (₹38.0L)</option>
            <option value="7">Jul (₹37.6L)</option>
            <option value="8">Aug (₹33.1L)</option>
            <option value="9">Sep (₹27.3L)</option>
            <option value="10">Oct (₹37.3L)</option>
            <option value="11">Nov (₹33.2L)</option>
            <option value="12">Dec (₹35.2L)</option>
          </select>
        </div>

        <!-- Region Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Region</label>
          <select id="regionFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Regions</option>
            <option value="North">North (₹1.01 Cr)</option>
            <option value="South">South (₹1.02 Cr)</option>
            <option value="West">West (₹97.3L)</option>
            <option value="East">East (₹57.3L)</option>
            <option value="Central">Central (₹54.4L)</option>
          </select>
        </div>

        <!-- Category Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Category</label>
          <select id="categoryFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Categories</option>
            <option value="Electronics">Electronics (77.6%)</option>
            <option value="Home & Kitchen">Home & Kitchen (10.1%)</option>
            <option value="Fashion">Fashion (8.7%)</option>
            <option value="Health & Personal Care">Health & Care (1.7%)</option>
            <option value="Books">Books (1.1%)</option>
            <option value="Others">Others (0.9%)</option>
          </select>
        </div>

        <!-- Order Status Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Status</label>
          <select id="statusFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Statuses</option>
            <option value="Delivered">Delivered (3,925)</option>
            <option value="Shipped">Shipped (399)</option>
            <option value="Processing">Processing (277)</option>
            <option value="Cancelled">Cancelled (256)</option>
            <option value="Returned">Returned (143)</option>
          </select>
        </div>

        <!-- Payment Method Filter -->
        <div>
          <label class="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">Payment</label>
          <select id="paymentFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amz-orange">
            <option value="ALL">All Methods</option>
            <option value="UPI">UPI (₹1.73 Cr)</option>
            <option value="Credit Card">Credit Card (₹67.8L)</option>
            <option value="Debit Card">Debit Card (₹61.9L)</option>
            <option value="Amazon Pay">Amazon Pay (₹52.0L)</option>
            <option value="Cash on Delivery">Cash on Delivery (₹36.0L)</option>
            <option value="Net Banking">Net Banking (₹20.9L)</option>
          </select>
        </div>
      </div>
    </section>

    <!-- Top KPI Cards Row (Glowing Glass Cards) -->
    <section class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      
      <!-- Card 1: Total Revenue -->
      <div class="glass-panel p-4 relative overflow-hidden group glow-border-amber">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-amz-orange/10 rounded-full blur-xl group-hover:bg-amz-orange/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Total Sales (GMV)</span>
          <span class="p-1 rounded bg-amz-orange/10 text-amz-orange">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-white tracking-tight" id="kpiTotalRevenue">₹4.12 Cr</div>
        <div class="flex items-center gap-1.5 mt-2 text-[11px] text-emerald-400">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
          <span>Target Achieved (102.4%)</span>
        </div>
      </div>

      <!-- Card 2: Total Orders & Volume -->
      <div class="glass-panel p-4 relative overflow-hidden group glow-border-cyan">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-amz-cyan/10 rounded-full blur-xl group-hover:bg-amz-cyan/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Total Orders</span>
          <span class="p-1 rounded bg-amz-cyan/10 text-amz-cyan">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-white tracking-tight" id="kpiTotalOrders">5,000</div>
        <div class="flex items-center justify-between mt-2 text-[11px] text-slate-400">
          <span id="kpiUnits">7,488 Units</span>
          <span class="text-amz-cyan font-mono" id="kpiAOV">AOV: ₹8,232</span>
        </div>
      </div>

      <!-- Card 3: Delivered Orders & Revenue -->
      <div class="glass-panel p-4 relative overflow-hidden group glow-border-emerald">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Fulfilled (Delivered)</span>
          <span class="p-1 rounded bg-emerald-500/10 text-emerald-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-emerald-400 tracking-tight" id="kpiDeliveredRevenue">₹3.23 Cr</div>
        <div class="flex items-center justify-between mt-2 text-[11px] text-slate-400">
          <span id="kpiDeliveredCount">3,925 orders</span>
          <span class="text-emerald-400 font-semibold" id="kpiDeliveredPct">78.5% Rate</span>
        </div>
      </div>

      <!-- Card 4: Delivery SLA On-Time Rate -->
      <div class="glass-panel p-4 relative overflow-hidden group border-amber-500/40 shadow-glow-amber">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-amber-500/10 rounded-full blur-xl group-hover:bg-amber-500/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">On-Time SLA Rate</span>
          <span class="p-1 rounded bg-amber-500/10 text-amber-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-amber-400 tracking-tight" id="kpiOnTimeRate">49.55%</div>
        <div class="flex items-center justify-between mt-2 text-[11px] text-slate-400">
          <span id="kpiAvgDelivery">Avg 4.0 Days</span>
          <span class="text-amber-400" id="kpiLateOrders">1,980 Delayed</span>
        </div>
      </div>

      <!-- Card 5: Discounts & Subsidies -->
      <div class="glass-panel p-4 relative overflow-hidden group glow-border-purple">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-purple-500/10 rounded-full blur-xl group-hover:bg-purple-500/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Promotional Discounts</span>
          <span class="p-1 rounded bg-purple-500/10 text-purple-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-purple-300 tracking-tight" id="kpiDiscounts">₹31.45 L</div>
        <div class="flex items-center justify-between mt-2 text-[11px] text-slate-400">
          <span>7.6% of GMV</span>
          <span class="text-purple-400" id="kpiShipping">Ship: ₹2.45L</span>
        </div>
      </div>

      <!-- Card 6: Leakage (Cancelled & Returned) -->
      <div class="glass-panel p-4 relative overflow-hidden group border-rose-500/40 shadow-glow-rose">
        <div class="absolute -right-4 -bottom-4 w-20 h-20 bg-rose-500/10 rounded-full blur-xl group-hover:bg-rose-500/20 transition"></div>
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Cancelled / Returned</span>
          <span class="p-1 rounded bg-rose-500/10 text-rose-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-rose-400 tracking-tight" id="kpiCancelledCount">399 Orders</div>
        <div class="flex items-center justify-between mt-2 text-[11px] text-slate-400">
          <span id="kpiCancelledRate">8.0% Rate</span>
          <span class="text-rose-400" id="kpiCancelledVal">~₹32.8L Risk</span>
        </div>
      </div>

    </section>

    <!-- Visual Dashboard Charts Grid -->
    <section class="grid grid-cols-1 lg:grid-cols-12 gap-6">

      <!-- Chart 1: Revenue Velocity & Order Volume Timeline (8 Cols) -->
      <div class="glass-panel p-5 lg:col-span-8 flex flex-col justify-between">
        <div class="flex items-center justify-between flex-wrap gap-2 mb-4">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amz-orange shadow-glow-amber"></span>
              Monthly Revenue Velocity & Order Trajectory
            </h2>
            <p class="text-xs text-slate-400">Dual-axis gradient area (Gross Revenue ₹) & volume bars across 2025</p>
          </div>
          <div class="flex items-center gap-4 text-xs">
            <span class="inline-flex items-center gap-1.5 text-amz-orange font-semibold">
              <span class="w-3 h-3 rounded-sm bg-amz-orange"></span> Sales (INR)
            </span>
            <span class="inline-flex items-center gap-1.5 text-amz-cyan font-semibold">
              <span class="w-3 h-3 rounded-sm bg-amz-cyan"></span> Orders Count
            </span>
          </div>
        </div>
        <div class="relative w-full h-[320px] lg:h-[350px]">
          <canvas id="monthlyTrendChart"></canvas>
        </div>
      </div>

      <!-- Chart 2: Regional Performance Doughnut (4 Cols) -->
      <div class="glass-panel p-5 lg:col-span-4 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-2">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amz-cyan shadow-glow-cyan"></span>
              Regional Sales Distribution
            </h2>
            <p class="text-xs text-slate-400">Revenue share across geographic clusters</p>
          </div>
        </div>
        <div class="relative w-full h-[280px] flex items-center justify-center">
          <canvas id="regionDoughnutChart"></canvas>
        </div>
        <div id="regionLegend" class="grid grid-cols-3 gap-2 pt-3 border-t border-slate-700/60 text-center text-xs">
          <!-- Dynamically populated -->
        </div>
      </div>

      <!-- Chart 3: Category Revenue Dominance (Horizontal Bar) (6 Cols) -->
      <div class="glass-panel p-5 lg:col-span-6 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-purple-500 shadow-glow-purple"></span>
              Category Revenue Breakdown
            </h2>
            <p class="text-xs text-slate-400">Electronics driving 77.6% of platform GMV</p>
          </div>
        </div>
        <div class="relative w-full h-[300px]">
          <canvas id="categoryBarChart"></canvas>
        </div>
      </div>

      <!-- Chart 4: Payment Gateway Ecosystem (6 Cols) -->
      <div class="glass-panel p-5 lg:col-span-6 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-glow-emerald"></span>
              Payment Method Adoption & Volume
            </h2>
            <p class="text-xs text-slate-400">UPI dominance (42.0%) vs Credit Cards & Debit Cards</p>
          </div>
        </div>
        <div class="relative w-full h-[300px]">
          <canvas id="paymentChart"></canvas>
        </div>
      </div>

      <!-- Chart 5: Top 10 Revenue-Generating Flagship Products (7 Cols) -->
      <div class="glass-panel p-5 lg:col-span-7 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-glow-amber"></span>
              Top 10 Flagship Products
            </h2>
            <p class="text-xs text-slate-400">ByteBook 14 Laptop and Nova X5 leading the revenue leaderboard</p>
          </div>
        </div>
        <div class="relative w-full h-[340px]">
          <canvas id="topProductsChart"></canvas>
        </div>
      </div>

      <!-- Chart 6: Delivery SLA & Latency by Region (5 Cols) -->
      <div class="glass-panel p-5 lg:col-span-5 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-glow-rose"></span>
              Logistics SLA: On-Time vs Delayed
            </h2>
            <p class="text-xs text-slate-400">Critical operational bottleneck: 49.55% overall on-time delivery</p>
          </div>
        </div>
        <div class="relative w-full h-[340px]">
          <canvas id="deliverySlaChart"></canvas>
        </div>
      </div>

    </section>

    <!-- Customer Segments & Strategic Insights Grid -->
    <section class="grid grid-cols-1 md:grid-cols-3 gap-5">
      <!-- Segment 1: Individual Buyers -->
      <div class="glass-panel p-5 border-l-4 border-l-blue-500">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-blue-400">Core Retail</span>
          <span class="text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full font-mono">59.8% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Individual Consumers</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales:</span>
            <span class="font-bold text-white font-mono" id="segIndRevenue">₹2.54 Cr</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segIndAOV">₹8,493</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Unique Customers:</span>
            <span class="font-bold text-white font-mono" id="segIndUsers">1,668</span>
          </div>
        </div>
        <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          Largest GMV contributor with highest average order value. Driven by smartphone and personal computing purchases.
        </p>
      </div>

      <!-- Segment 2: Prime Members -->
      <div class="glass-panel p-5 border-l-4 border-l-amz-orange glow-border-amber">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-amz-orange flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            Prime Subscription
          </span>
          <span class="text-xs bg-amz-orange/20 text-amz-orange px-2 py-0.5 rounded-full font-mono font-bold">30.3% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Amazon Prime Loyalty</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales:</span>
            <span class="font-bold text-amz-orange font-mono" id="segPrimeRevenue">₹1.21 Cr</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segPrimeAOV">₹7,950</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Subscribers:</span>
            <span class="font-bold text-white font-mono" id="segPrimeUsers">828 Active</span>
          </div>
        </div>
        <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          High purchase frequency across Home, Audio, and Fashion. Expects guaranteed 2-day delivery; heavily impacted by late deliveries.
        </p>
      </div>

      <!-- Segment 3: Small Business -->
      <div class="glass-panel p-5 border-l-4 border-l-purple-500">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-purple-400">B2B / Commercial</span>
          <span class="text-xs bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-mono">9.8% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Small Business & Enterprise</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales:</span>
            <span class="font-bold text-purple-300 font-mono" id="segBizRevenue">₹36.95 L</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segBizAOV">₹7,525</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>B2B Accounts:</span>
            <span class="font-bold text-white font-mono" id="segBizUsers">284 Verified</span>
          </div>
        </div>
        <p class="text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          Steady recurring demand for stationery, computing chargers, appliances, and cookware bulk packs with GST invoicing.
        </p>
      </div>
    </section>

    <!-- Interactive Data Table (Live Search, Sorting, Filtering, Export) -->
    <section class="glass-panel p-5 space-y-4">
      <div class="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
            <svg class="w-5 h-5 text-amz-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
            Transactional Records Explorer
          </h2>
          <p class="text-xs text-slate-400">Real-time filtered transactions with sorting and fulfillment audit</p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400">Rows per page:</span>
          <select id="pageSizeSelect" onchange="changePageSize(this.value)" class="bg-slate-900 text-slate-200 rounded px-2 py-1 border border-slate-700">
            <option value="10">10</option>
            <option value="25" selected>25</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
          <span id="tableCountBadge" class="font-mono text-slate-300 px-2 py-1 bg-slate-800 rounded border border-slate-700">Showing 1-25 of 5000</span>
        </div>
      </div>

      <!-- Table Wrapper -->
      <div class="overflow-x-auto rounded-lg border border-slate-700/80">
        <table class="w-full text-left text-xs text-slate-300">
          <thead class="bg-slate-900/90 text-[11px] uppercase tracking-wider text-slate-400 font-semibold border-b border-slate-700">
            <tr>
              <th onclick="sortTable(0)" class="p-3 cursor-pointer hover:text-white">Order ID ⬍</th>
              <th onclick="sortTable(1)" class="p-3 cursor-pointer hover:text-white">Date ⬍</th>
              <th onclick="sortTable(2)" class="p-3 cursor-pointer hover:text-white">Product & Category ⬍</th>
              <th onclick="sortTable(5)" class="p-3 cursor-pointer hover:text-white text-center">Qty ⬍</th>
              <th onclick="sortTable(9)" class="p-3 cursor-pointer hover:text-white text-right">Net Sales (INR) ⬍</th>
              <th onclick="sortTable(10)" class="p-3 cursor-pointer hover:text-white">Payment ⬍</th>
              <th onclick="sortTable(11)" class="p-3 cursor-pointer hover:text-white">Status ⬍</th>
              <th onclick="sortTable(12)" class="p-3 cursor-pointer hover:text-white">Location ⬍</th>
              <th onclick="sortTable(15)" class="p-3 cursor-pointer hover:text-white text-center">Delivery / SLA ⬍</th>
              <th class="p-3 text-center">Action</th>
            </tr>
          </thead>
          <tbody id="ordersTableBody" class="divide-y divide-slate-800/80 bg-slate-900/40">
            <!-- Populated via Javascript -->
          </tbody>
        </table>
      </div>

      <!-- Table Pagination Bar -->
      <div class="flex items-center justify-between flex-wrap gap-3 pt-2">
        <div class="text-xs text-slate-400">
          Page <span id="currentPageNum" class="text-white font-bold font-mono">1</span> of <span id="totalPageNum" class="text-white font-bold font-mono">200</span>
        </div>
        <div class="flex items-center gap-1.5">
          <button onclick="prevPage()" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold disabled:opacity-40 transition" id="prevBtn">Previous</button>
          <button onclick="nextPage()" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold disabled:opacity-40 transition" id="nextBtn">Next</button>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="glass-panel p-4 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
      <div class="flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-amz-orange"></span>
        <span>Amazon India Analytics Portal • Built for Business Operations & Supply Chain Teams</span>
      </div>
      <div>
        <span>Dataset: 5,000 Transactions (IN-2025-000001 to IN-2025-005000) • Currency: INR (₹)</span>
      </div>
    </footer>

  </div>

  <!-- Modal: Order Details Drilldown -->
  <div id="orderDetailModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm hidden">
    <div class="glass-panel w-full max-w-xl p-6 glow-border-amber relative">
      <button onclick="closeModal('orderDetailModal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
      <div id="modalOrderContent">
        <!-- Rendered via JS -->
      </div>
    </div>
  </div>

  <!-- Modal: Executive Analytics Narrative & Recommendations -->
  <div id="analyticsReportModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md hidden">
    <div class="glass-panel w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 lg:p-8 glow-border-cyan relative space-y-6">
      <button onclick="closeModal('analyticsReportModal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>

      <div class="border-b border-slate-700/80 pb-4">
        <span class="text-xs font-bold text-amz-cyan uppercase tracking-wider">Executive Intelligence Briefing</span>
        <h2 class="text-2xl font-display font-bold text-white mt-1">Amazon India 2025 Sales & Fulfillment Diagnostics</h2>
        <p class="text-xs text-slate-400 mt-1">Comprehensive findings from 5,000 orders across 28 catalog items and 35 fulfillment hubs.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-amz-orange uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            1. Revenue Concentration Risk
          </h4>
          <p class="text-slate-300 leading-relaxed">
            The <strong>Electronics</strong> category dominates total gross merchandise value (GMV) at <strong>₹3.19 Crore (77.6%)</strong>. Just two products—<strong>ByteBook 14 Laptop</strong> (₹1.97 Cr, 47.8%) and <strong>Nova X5 Smartphone</strong> (₹69.2L, 16.8%)—account for <strong>64.6%</strong> of entire revenue. While these products provide massive basket value, any supply shortage or competitor price undercutting poses severe revenue vulnerability.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            2. The 49.55% Delivery SLA Crisis
          </h4>
          <p class="text-slate-300 leading-relaxed">
            Out of 3,925 delivered orders, <strong>1,980 orders (50.45%) were delivered after the promised delivery date</strong>, with an average delay of <strong>2.39 late days</strong>. This severely impacts Prime Member trust (30.3% of order volume). Cities like Shimla, Patna, and Guwahati suffer higher late day counts due to mountainous and eastern hub bottlenecks.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            3. UPI as the Digital Commerce Engine
          </h4>
          <p class="text-slate-300 leading-relaxed">
            <strong>UPI drives ₹1.73 Crore (42.0%)</strong> of GMV, nearly tripling Credit Card (16.5%) and Debit Card (15.0%). Amazon Pay accounts for 12.6% (₹52.0L). <strong>Cash on Delivery (8.7%) has a 2.4x higher cancellation and return rate</strong> than prepaid orders, incurring avoidable return freight charges.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-purple-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            4. Prime vs B2B Monetization Potential
          </h4>
          <p class="text-slate-300 leading-relaxed">
            Prime members generate <strong>₹1.21 Crore with 1,516 orders</strong> and repeat purchasing habits across Home Decor and Beauty. Small Business orders (₹36.95L, 491 orders) are currently under-penetrated in Tier-2 manufacturing hubs like Surat and Jabalpur.
          </p>
        </div>
      </div>

      <div class="bg-slate-900/90 p-4 rounded-xl border border-amz-border text-xs space-y-2">
        <h4 class="font-bold text-white text-sm">Strategic Recommendations & Action Items</h4>
        <ul class="list-disc list-inside space-y-1.5 text-slate-300">
          <li><strong class="text-amz-orange">Fulfillment Center Rebalancing:</strong> Establish regional forward stocking for ByteBook Laptops & Ceiling Fans in North & East hubs (Shimla/Chandigarh and Siliguri/Ranchi) to recover SLA from 49.55% to &gt;85%.</li>
          <li><strong class="text-amz-cyan">Incentivize UPI & Amazon Pay over COD:</strong> Offer instant 2-3% checkout cashback for converting Cash-on-Delivery to UPI to eliminate ₹14.2L in RTO (Return-to-Origin) logistics waste.</li>
          <li><strong class="text-emerald-400">Prime Retention Guarantee:</strong> Institute automated 500 loyalty point compensation for Prime orders delayed past promised delivery dates to protect subscriber retention.</li>
          <li><strong class="text-purple-400">Bundle High-Margin Categories:</strong> Cross-sell FestiveSilk Sarees and Neem Care Kits alongside high-ticket computing products to lift basket diversity.</li>
        </ul>
      </div>
    </div>
  </div>

  <!-- Raw Compact Dataset -->
  <script>
    const RAW_ORDERS = ${JSON.stringify(compactOrders)};
  </script>

  <!-- Application Logic -->
  <script>
    // State
    let filteredOrders = [...RAW_ORDERS];
    let currencyMode = 'crore'; // 'crore' or 'full'
    let currentPage = 1;
    let pageSize = 25;
    let currentSortCol = 1;
    let currentSortAsc = false;
    let debounceTimer = null;

    // Charts instances
    let monthlyChart = null;
    let regionChart = null;
    let categoryChart = null;
    let paymentChart = null;
    let topProductsChart = null;
    let deliverySlaChart = null;

    // Formatters
    function formatINR(val, compact = false) {
      if (val === undefined || val === null || isNaN(val)) return '₹0';
      if (currencyMode === 'crore' || compact) {
        if (Math.abs(val) >= 10000000) {
          return '₹' + (val / 10000000).toFixed(2) + ' Cr';
        } else if (Math.abs(val) >= 100000) {
          return '₹' + (val / 100000).toFixed(2) + ' L';
        } else if (Math.abs(val) >= 1000) {
          return '₹' + (val / 1000).toFixed(1) + ' k';
        }
      }
      return '₹' + Math.round(val).toLocaleString('en-IN');
    }

    function setCurrencyMode(mode) {
      currencyMode = mode;
      document.getElementById('currBtnCrore').className = mode === 'crore' 
        ? 'px-3 py-1.5 rounded-md font-semibold transition text-amz-orange bg-slate-800' 
        : 'px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white';
      document.getElementById('currBtnFull').className = mode === 'full' 
        ? 'px-3 py-1.5 rounded-md font-semibold transition text-amz-orange bg-slate-800' 
        : 'px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white';
      updateUI();
    }

    // Modal Helpers
    function toggleModal(id) {
      const el = document.getElementById(id);
      if (el) el.classList.toggle('hidden');
    }
    function closeModal(id) {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    }

    function openOrderDetail(idx) {
      const o = filteredOrders[idx];
      if (!o) return;
      
      const isLate = o[16] > 0;
      const statusColor = getStatusColor(o[11]);

      const html = \`
        <div class="space-y-4">
          <div class="flex items-center justify-between border-b border-slate-700/80 pb-3">
            <div>
              <span class="text-xs font-mono text-amz-orange">\${o[0]}</span>
              <h3 class="text-lg font-bold text-white">\${o[2]}</h3>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-bold \${statusColor}">\${o[11]}</span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Order Date</span>
              <span class="font-semibold text-white">\${o[1]} (\${o[17]})</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Payment Method</span>
              <span class="font-semibold text-white">\${o[10]}</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Customer & Segment</span>
              <span class="font-semibold text-white">\${o[20]} (\${o[19]})</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Fulfillment Destination</span>
              <span class="font-semibold text-white">\${o[13]}, \${o[14]} (\${o[12]})</span>
            </div>
          </div>

          <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 text-xs space-y-2">
            <div class="flex justify-between text-slate-300">
              <span>Unit Price x Quantity:</span>
              <span>₹\${o[6].toLocaleString('en-IN')} x \${o[5]} = ₹\${(o[6]*o[5]).toLocaleString('en-IN')}</span>
            </div>
            <div class="flex justify-between text-rose-400">
              <span>Discount Given:</span>
              <span>-₹\${o[7].toLocaleString('en-IN')}</span>
            </div>
            <div class="flex justify-between text-slate-300">
              <span>Shipping Fee:</span>
              <span>₹\${o[8]}</span>
            </div>
            <div class="flex justify-between text-sm font-bold text-white pt-2 border-t border-slate-800">
              <span class="text-amz-orange">Total Order Value:</span>
              <span class="text-amz-orange font-mono">₹\${o[9].toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div class="p-3 rounded-lg bg-slate-900 border \${isLate ? 'border-rose-500/30' : 'border-emerald-500/30'} flex items-center justify-between text-xs">
            <div>
              <span class="text-slate-400 block">Delivery Duration:</span>
              <span class="font-semibold text-white">\${o[15] >= 0 ? o[15] + ' Days' : 'In Transit / Not Delivered'}</span>
            </div>
            <div class="text-right">
              <span class="text-slate-400 block">SLA Status:</span>
              <span class="font-bold \${isLate ? 'text-rose-400' : 'text-emerald-400'}">\${isLate ? 'Delayed by ' + o[16] + ' days' : (o[15] >= 0 ? 'On-Time Guaranteed' : 'Pending')}</span>
            </div>
          </div>
        </div>
      \`;

      document.getElementById('modalOrderContent').innerHTML = html;
      document.getElementById('orderDetailModal').classList.remove('hidden');
    }

    function getStatusColor(status) {
      switch(status) {
        case 'Delivered': return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40';
        case 'Shipped': return 'bg-amz-cyan/20 text-amz-cyan border border-amz-cyan/40';
        case 'Processing': return 'bg-amber-500/20 text-amber-300 border border-amber-500/40';
        case 'Cancelled': return 'bg-rose-500/20 text-rose-400 border border-rose-500/40';
        case 'Returned': return 'bg-purple-500/20 text-purple-300 border border-purple-500/40';
        default: return 'bg-slate-700 text-slate-300';
      }
    }

    // Filter Logic
    function debounceFilter() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        applyFilters();
      }, 150);
    }

    function applyPreset(preset) {
      // Clear specific inputs first
      document.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('bg-amz-orange', 'text-black', 'active-preset'));
      
      resetFilterInputs();

      if (preset === 'topFlagships') {
        document.getElementById('categoryFilter').value = 'Electronics';
      } else if (preset === 'prime') {
        // We filter customer segment for prime
        customPresetFilter = 'Prime Member';
      } else if (preset === 'delayed') {
        customPresetFilter = 'DELAYED';
      } else if (preset === 'highValue') {
        customPresetFilter = 'HIGH_VALUE';
      } else if (preset === 'upi') {
        document.getElementById('paymentFilter').value = 'UPI';
      } else {
        customPresetFilter = null;
      }

      applyFilters();
    }

    let customPresetFilter = null;

    function resetFilterInputs() {
      document.getElementById('searchInput').value = '';
      document.getElementById('quarterFilter').value = 'ALL';
      document.getElementById('monthFilter').value = 'ALL';
      document.getElementById('regionFilter').value = 'ALL';
      document.getElementById('categoryFilter').value = 'ALL';
      document.getElementById('statusFilter').value = 'ALL';
      document.getElementById('paymentFilter').value = 'ALL';
    }

    function resetAllFilters() {
      customPresetFilter = null;
      resetFilterInputs();
      applyFilters();
    }

    function applyFilters() {
      const q = document.getElementById('searchInput').value.trim().toLowerCase();
      const quarter = document.getElementById('quarterFilter').value;
      const month = document.getElementById('monthFilter').value;
      const region = document.getElementById('regionFilter').value;
      const category = document.getElementById('categoryFilter').value;
      const status = document.getElementById('statusFilter').value;
      const payment = document.getElementById('paymentFilter').value;

      filteredOrders = RAW_ORDERS.filter(o => {
        // [0:id, 1:date, 2:prod, 3:cat, 4:subcat, 5:qty, 6:price, 7:disc, 8:ship, 9:sales, 10:pay, 11:status, 12:region, 13:city, 14:state, 15:delDays, 16:lateDays, 17:qtr, 18:mNum, 19:custSeg, 20:custName]
        if (quarter !== 'ALL' && o[17] !== quarter) return false;
        if (month !== 'ALL' && o[18] !== parseInt(month)) return false;
        if (region !== 'ALL' && o[12] !== region) return false;
        if (category !== 'ALL' && o[3] !== category) return false;
        if (status !== 'ALL' && o[11] !== status) return false;
        if (payment !== 'ALL' && o[10] !== payment) return false;

        // Custom Presets
        if (customPresetFilter === 'Prime Member' && o[19] !== 'Prime Member') return false;
        if (customPresetFilter === 'DELAYED' && (o[11] !== 'Delivered' || o[16] <= 0)) return false;
        if (customPresetFilter === 'HIGH_VALUE' && o[9] < 20000) return false;

        // Search text
        if (q) {
          const matchStr = (o[0] + ' ' + o[2] + ' ' + o[3] + ' ' + o[13] + ' ' + o[14] + ' ' + o[20]).toLowerCase();
          if (!matchStr.includes(q)) return false;
        }

        return true;
      });

      currentPage = 1;
      updateUI();
    }

    function updateUI() {
      updateActiveFilterBadge();
      updateKPICards();
      updateCharts();
      renderTable();
    }

    function updateActiveFilterBadge() {
      const total = RAW_ORDERS.length;
      const current = filteredOrders.length;
      const pct = ((current / total) * 100).toFixed(1);
      const badge = document.getElementById('activeFilterBadge');
      if (current === total) {
        badge.textContent = 'All 5,000 Orders';
        badge.className = 'text-xs px-2 py-0.5 rounded-full bg-amz-cyan/20 text-amz-cyan border border-amz-cyan/40 font-mono';
      } else {
        badge.textContent = \`\${current.toLocaleString()} of \${total.toLocaleString()} Orders (\${pct}%)\`;
        badge.className = 'text-xs px-2.5 py-0.5 rounded-full bg-amz-orange/20 text-amz-orange border border-amz-orange/40 font-mono font-bold';
      }
    }

    function updateKPICards() {
      let totalSales = 0;
      let totalQty = 0;
      let totalDisc = 0;
      let totalShip = 0;
      let deliveredRev = 0;
      let deliveredCount = 0;
      let lateCount = 0;
      let totalLateDays = 0;
      let totalDelDays = 0;
      let countWithDelDays = 0;
      let cancelledReturnedCount = 0;
      let cancelledReturnedRev = 0;

      const segRev = { 'Individual': 0, 'Prime Member': 0, 'Small Business': 0 };
      const segOrders = { 'Individual': 0, 'Prime Member': 0, 'Small Business': 0 };

      filteredOrders.forEach(o => {
        const sales = o[9];
        totalSales += sales;
        totalQty += o[5];
        totalDisc += o[7];
        totalShip += o[8];

        if (o[11] === 'Delivered') {
          deliveredCount++;
          deliveredRev += sales;
          if (o[15] >= 0) {
            countWithDelDays++;
            totalDelDays += o[15];
          }
          if (o[16] > 0) {
            lateCount++;
            totalLateDays += o[16];
          }
        } else if (o[11] === 'Cancelled' || o[11] === 'Returned') {
          cancelledReturnedCount++;
          cancelledReturnedRev += sales;
        }

        const seg = o[19];
        if (segRev[seg] !== undefined) {
          segRev[seg] += sales;
          segOrders[seg] += 1;
        }
      });

      const totalOrders = filteredOrders.length;
      const aov = totalOrders > 0 ? totalSales / totalOrders : 0;
      const onTimeRate = deliveredCount > 0 ? ((deliveredCount - lateCount) / deliveredCount) * 100 : 0;
      const avgDays = countWithDelDays > 0 ? (totalDelDays / countWithDelDays).toFixed(1) : 0;
      const deliveredPct = totalOrders > 0 ? ((deliveredCount / totalOrders) * 100).toFixed(1) : 0;
      const cancelRate = totalOrders > 0 ? ((cancelledReturnedCount / totalOrders) * 100).toFixed(1) : 0;

      document.getElementById('kpiTotalRevenue').textContent = formatINR(totalSales);
      document.getElementById('kpiTotalOrders').textContent = totalOrders.toLocaleString('en-IN');
      document.getElementById('kpiUnits').textContent = totalQty.toLocaleString('en-IN') + ' Units';
      document.getElementById('kpiAOV').textContent = 'AOV: ' + formatINR(aov, true);

      document.getElementById('kpiDeliveredRevenue').textContent = formatINR(deliveredRev);
      document.getElementById('kpiDeliveredCount').textContent = deliveredCount.toLocaleString('en-IN') + ' orders';
      document.getElementById('kpiDeliveredPct').textContent = deliveredPct + '% Rate';

      document.getElementById('kpiOnTimeRate').textContent = onTimeRate.toFixed(2) + '%';
      document.getElementById('kpiAvgDelivery').textContent = 'Avg ' + avgDays + ' Days';
      document.getElementById('kpiLateOrders').textContent = lateCount.toLocaleString('en-IN') + ' Delayed';

      document.getElementById('kpiDiscounts').textContent = formatINR(totalDisc);
      document.getElementById('kpiShipping').textContent = 'Ship: ' + formatINR(totalShip, true);

      document.getElementById('kpiCancelledCount').textContent = cancelledReturnedCount.toLocaleString('en-IN') + ' Orders';
      document.getElementById('kpiCancelledRate').textContent = cancelRate + '% Rate';
      document.getElementById('kpiCancelledVal').textContent = '~' + formatINR(cancelledReturnedRev, true) + ' Risk';

      // Segment cards
      document.getElementById('segIndRevenue').textContent = formatINR(segRev['Individual']);
      document.getElementById('segIndAOV').textContent = 'AOV: ' + formatINR(segOrders['Individual'] > 0 ? segRev['Individual'] / segOrders['Individual'] : 0);

      document.getElementById('segPrimeRevenue').textContent = formatINR(segRev['Prime Member']);
      document.getElementById('segPrimeAOV').textContent = 'AOV: ' + formatINR(segOrders['Prime Member'] > 0 ? segRev['Prime Member'] / segOrders['Prime Member'] : 0);

      document.getElementById('segBizRevenue').textContent = formatINR(segRev['Small Business']);
      document.getElementById('segBizAOV').textContent = 'AOV: ' + formatINR(segOrders['Small Business'] > 0 ? segRev['Small Business'] / segOrders['Small Business'] : 0);
    }

    // Chart.js Glowing Gradients Helpers
    function createVerticalGradient(ctx, colorTop, colorBottom) {
      const gradient = ctx.createLinearGradient(0, 0, 0, 300);
      gradient.addColorStop(0, colorTop);
      gradient.addColorStop(1, colorBottom);
      return gradient;
    }

    // Chart Initializers
    function initCharts() {
      // 1. Monthly Trends Chart (Area + Bar)
      const ctxMonthly = document.getElementById('monthlyTrendChart').getContext('2d');
      monthlyChart = new Chart(ctxMonthly, {
        type: 'bar',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          datasets: [
            {
              type: 'line',
              label: 'Sales Revenue (INR)',
              data: [],
              borderColor: '#FF9900',
              borderWidth: 3,
              pointBackgroundColor: '#FFA41C',
              pointBorderColor: '#FFFFFF',
              pointRadius: 4,
              pointHoverRadius: 7,
              tension: 0.35,
              fill: true,
              backgroundColor: function(context) {
                const chart = context.chart;
                const {ctx, chartArea} = chart;
                if (!chartArea) return null;
                const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
                g.addColorStop(0, 'rgba(255, 153, 0, 0.42)');
                g.addColorStop(0.7, 'rgba(255, 153, 0, 0.08)');
                g.addColorStop(1, 'rgba(255, 153, 0, 0)');
                return g;
              },
              yAxisID: 'y'
            },
            {
              type: 'bar',
              label: 'Orders Count',
              data: [],
              backgroundColor: function(context) {
                const chart = context.chart;
                const {ctx, chartArea} = chart;
                if (!chartArea) return null;
                const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
                g.addColorStop(0, 'rgba(0, 229, 255, 0.65)');
                g.addColorStop(1, 'rgba(0, 180, 216, 0.15)');
                return g;
              },
              borderRadius: 6,
              borderSkipped: false,
              barPercentage: 0.38,
              yAxisID: 'y1'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              titleColor: '#FF9900',
              bodyColor: '#F8FAFC',
              borderColor: '#23324A',
              borderWidth: 1,
              padding: 12,
              callbacks: {
                label: function(c) {
                  if (c.dataset.yAxisID === 'y') {
                    return 'Sales: ₹' + Math.round(c.raw).toLocaleString('en-IN');
                  }
                  return 'Orders: ' + c.raw + ' orders';
                }
              }
            }
          },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94A3B8', font: { size: 11 } }
            },
            y: {
              type: 'linear',
              position: 'left',
              grid: { color: 'rgba(255, 255, 255, 0.06)' },
              ticks: {
                color: '#FF9900',
                callback: v => formatINR(v, true)
              }
            },
            y1: {
              type: 'linear',
              position: 'right',
              grid: { drawOnChartArea: false },
              ticks: { color: '#00E5FF' }
            }
          }
        }
      });

      // 2. Region Doughnut Chart
      const ctxRegion = document.getElementById('regionDoughnutChart').getContext('2d');
      regionChart = new Chart(ctxRegion, {
        type: 'doughnut',
        data: {
          labels: ['North', 'South', 'West', 'East', 'Central'],
          datasets: [{
            data: [],
            backgroundColor: [
              '#FF9900',
              '#00E5FF',
              '#A855F7',
              '#10B981',
              '#F43F5E'
            ],
            borderColor: '#0B0F19',
            borderWidth: 3,
            hoverOffset: 10
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '72%',
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: '#23324A',
              borderWidth: 1,
              callbacks: {
                label: function(c) {
                  return ' ' + c.label + ': ' + formatINR(c.raw);
                }
              }
            }
          }
        }
      });

      // 3. Category Horizontal Bar Chart
      const ctxCat = document.getElementById('categoryBarChart').getContext('2d');
      categoryChart = new Chart(ctxCat, {
        type: 'bar',
        data: {
          labels: [],
          datasets: [{
            axis: 'y',
            label: 'Category Revenue',
            data: [],
            backgroundColor: [
              'rgba(255, 153, 0, 0.85)',
              'rgba(0, 229, 255, 0.85)',
              'rgba(168, 85, 247, 0.85)',
              'rgba(16, 185, 129, 0.85)',
              'rgba(244, 63, 94, 0.85)',
              'rgba(59, 130, 246, 0.85)'
            ],
            borderRadius: 6,
            borderSkipped: false
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: '#23324A',
              borderWidth: 1,
              callbacks: {
                label: function(c) {
                  return ' Sales: ' + formatINR(c.raw);
                }
              }
            }
          },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94A3B8', callback: v => formatINR(v, true) }
            },
            y: {
              grid: { display: false },
              ticks: { color: '#F1F5F9', font: { weight: 600 } }
            }
          }
        }
      });

      // 4. Payment Method Chart
      const ctxPay = document.getElementById('paymentChart').getContext('2d');
      paymentChart = new Chart(ctxPay, {
        type: 'bar',
        data: {
          labels: [],
          datasets: [{
            label: 'Sales Revenue',
            data: [],
            backgroundColor: function(context) {
              const colors = [
                'rgba(16, 185, 129, 0.85)', // UPI
                'rgba(59, 130, 246, 0.85)',  // Credit Card
                'rgba(168, 85, 247, 0.85)', // Debit Card
                'rgba(255, 153, 0, 0.85)',  // Amazon Pay
                'rgba(244, 63, 94, 0.85)',  // COD
                'rgba(0, 229, 255, 0.85)'   // Net Banking
              ];
              return colors[context.dataIndex % colors.length];
            },
            borderRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: '#23324A',
              borderWidth: 1,
              callbacks: {
                label: function(c) {
                  return ' Sales: ' + formatINR(c.raw);
                }
              }
            }
          },
          scales: {
            x: {
              grid: { display: false },
              ticks: { color: '#E2E8F0', font: { size: 10.5, weight: 600 } }
            },
            y: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94A3B8', callback: v => formatINR(v, true) }
            }
          }
        }
      });

      // 5. Top Products Chart
      const ctxProd = document.getElementById('topProductsChart').getContext('2d');
      topProductsChart = new Chart(ctxProd, {
        type: 'bar',
        data: {
          labels: [],
          datasets: [{
            label: 'Gross Sales',
            data: [],
            backgroundColor: function(context) {
              const chart = context.chart;
              const {ctx, chartArea} = chart;
              if (!chartArea) return '#FF9900';
              const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
              g.addColorStop(0, '#FFA41C');
              g.addColorStop(1, '#FF7700');
              return g;
            },
            borderRadius: 6
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: '#23324A',
              borderWidth: 1,
              callbacks: {
                label: function(c) {
                  return ' Sales: ' + formatINR(c.raw);
                }
              }
            }
          },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94A3B8', callback: v => formatINR(v, true) }
            },
            y: {
              grid: { display: false },
              ticks: { color: '#F1F5F9', font: { size: 10.5 } }
            }
          }
        }
      });

      // 6. Delivery SLA Chart (Stacked on-time vs delayed by region)
      const ctxSla = document.getElementById('deliverySlaChart').getContext('2d');
      deliverySlaChart = new Chart(ctxSla, {
        type: 'bar',
        data: {
          labels: ['North', 'South', 'West', 'East', 'Central'],
          datasets: [
            {
              label: 'On-Time Guaranteed',
              data: [],
              backgroundColor: 'rgba(16, 185, 129, 0.85)',
              borderRadius: 6
            },
            {
              label: 'Delayed Delivery',
              data: [],
              backgroundColor: 'rgba(244, 63, 94, 0.85)',
              borderRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              stacked: true,
              grid: { display: false },
              ticks: { color: '#CBD5E1', font: { weight: 600 } }
            },
            y: {
              stacked: true,
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94A3B8' }
            }
          },
          plugins: {
            legend: {
              labels: { color: '#CBD5E1', boxWidth: 12, font: { size: 11 } }
            },
            tooltip: {
              backgroundColor: 'rgba(15, 23, 42, 0.95)',
              borderColor: '#23324A',
              borderWidth: 1
            }
          }
        }
      });
    }

    function updateCharts() {
      // 1. Monthly aggregated data
      const monthRev = new Array(12).fill(0);
      const monthOrders = new Array(12).fill(0);

      // 2. Region aggregated data
      const regionData = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };

      // 3. Category aggregated data
      const catData = {};

      // 4. Payment aggregated data
      const payData = {};

      // 5. Products aggregated data
      const prodData = {};

      // 6. SLA data
      const regionOnTime = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };
      const regionLate = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };

      filteredOrders.forEach(o => {
        const mIdx = o[18] - 1;
        if (mIdx >= 0 && mIdx < 12) {
          monthRev[mIdx] += o[9];
          monthOrders[mIdx] += 1;
        }

        if (regionData[o[12]] !== undefined) {
          regionData[o[12]] += o[9];
        }

        catData[o[3]] = (catData[o[3]] || 0) + o[9];
        payData[o[10]] = (payData[o[10]] || 0) + o[9];
        prodData[o[2]] = (prodData[o[2]] || 0) + o[9];

        if (o[11] === 'Delivered') {
          if (o[16] > 0) {
            if (regionLate[o[12]] !== undefined) regionLate[o[12]] += 1;
          } else {
            if (regionOnTime[o[12]] !== undefined) regionOnTime[o[12]] += 1;
          }
        }
      });

      // Update Monthly Chart
      monthlyChart.data.datasets[0].data = monthRev;
      monthlyChart.data.datasets[1].data = monthOrders;
      monthlyChart.update();

      // Update Region Chart
      const regKeys = ['North', 'South', 'West', 'East', 'Central'];
      regionChart.data.datasets[0].data = regKeys.map(k => regionData[k]);
      regionChart.update();

      // Update Region Legend
      const totalRegRev = Object.values(regionData).reduce((a,b)=>a+b, 0) || 1;
      const regColors = ['#FF9900', '#00E5FF', '#A855F7', '#10B981', '#F43F5E'];
      let regLegendHtml = '';
      regKeys.forEach((k, idx) => {
        const p = ((regionData[k] / totalRegRev) * 100).toFixed(1);
        regLegendHtml += \`
          <div class="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
            <span class="inline-block w-2.5 h-2.5 rounded-full mr-1.5" style="background:\${regColors[idx]}"></span>
            <span class="font-bold text-white">\${k}</span>
            <div class="text-[11px] text-slate-400 mt-0.5">\${formatINR(regionData[k], true)} (\${p}%)</div>
          </div>
        \`;
      });
      document.getElementById('regionLegend').innerHTML = regLegendHtml;

      // Update Category Chart
      const sortedCats = Object.entries(catData).sort((a,b) => b[1] - a[1]);
      categoryChart.data.labels = sortedCats.map(c => c[0]);
      categoryChart.data.datasets[0].data = sortedCats.map(c => c[1]);
      categoryChart.update();

      // Update Payment Chart
      const sortedPay = Object.entries(payData).sort((a,b) => b[1] - a[1]);
      paymentChart.data.labels = sortedPay.map(p => p[0]);
      paymentChart.data.datasets[0].data = sortedPay.map(p => p[1]);
      paymentChart.update();

      // Update Top Products Chart (top 8 for elegance)
      const sortedProds = Object.entries(prodData).sort((a,b) => b[1] - a[1]).slice(0, 8);
      topProductsChart.data.labels = sortedProds.map(p => p[0].length > 20 ? p[0].substring(0, 18) + '...' : p[0]);
      topProductsChart.data.datasets[0].data = sortedProds.map(p => p[1]);
      topProductsChart.update();

      // Update Delivery SLA Chart
      deliverySlaChart.data.datasets[0].data = regKeys.map(k => regionOnTime[k]);
      deliverySlaChart.data.datasets[1].data = regKeys.map(k => regionLate[k]);
      deliverySlaChart.update();
    }

    // Table Rendering & Sorting
    function sortTable(colIdx) {
      if (currentSortCol === colIdx) {
        currentSortAsc = !currentSortAsc;
      } else {
        currentSortCol = colIdx;
        currentSortAsc = true;
      }

      filteredOrders.sort((a, b) => {
        let vA = a[colIdx];
        let vB = b[colIdx];

        if (typeof vA === 'string') {
          return currentSortAsc ? vA.localeCompare(vB) : vB.localeCompare(vA);
        }
        return currentSortAsc ? (vA - vB) : (vB - vA);
      });

      renderTable();
    }

    function changePageSize(size) {
      pageSize = parseInt(size);
      currentPage = 1;
      renderTable();
    }

    function prevPage() {
      if (currentPage > 1) {
        currentPage--;
        renderTable();
      }
    }

    function nextPage() {
      const maxPage = Math.ceil(filteredOrders.length / pageSize);
      if (currentPage < maxPage) {
        currentPage++;
        renderTable();
      }
    }

    function renderTable() {
      const tbody = document.getElementById('ordersTableBody');
      const total = filteredOrders.length;
      const maxPage = Math.max(1, Math.ceil(total / pageSize));
      if (currentPage > maxPage) currentPage = maxPage;

      document.getElementById('currentPageNum').textContent = currentPage;
      document.getElementById('totalPageNum').textContent = maxPage;
      document.getElementById('prevBtn').disabled = (currentPage === 1);
      document.getElementById('nextBtn').disabled = (currentPage === maxPage || total === 0);

      const start = (currentPage - 1) * pageSize;
      const end = Math.min(start + pageSize, total);

      document.getElementById('tableCountBadge').textContent = total > 0 ? \`Showing \${start + 1}-\${end} of \${total.toLocaleString()}\` : 'No results found';

      if (total === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="p-8 text-center text-slate-400 font-medium">No orders match the selected filters.</td></tr>';
        return;
      }

      const paged = filteredOrders.slice(start, end);
      let html = '';

      paged.forEach((o, i) => {
        const globalIdx = start + i;
        const statusColor = getStatusColor(o[11]);
        const isLate = o[16] > 0;

        html += \`
          <tr class="hover:bg-slate-800/60 transition group cursor-pointer" onclick="openOrderDetail(\${globalIdx})">
            <td class="p-3 font-mono font-medium text-amz-orange">\${o[0]}</td>
            <td class="p-3 text-slate-400 whitespace-nowrap">\${o[1]}</td>
            <td class="p-3">
              <div class="font-medium text-white group-hover:text-amz-orange transition">\${o[2]}</div>
              <div class="text-[10px] text-slate-400">\${o[3]} • \${o[4]}</div>
            </td>
            <td class="p-3 text-center font-mono">\${o[5]}</td>
            <td class="p-3 text-right font-mono font-bold text-white">₹\${o[9].toLocaleString('en-IN')}</td>
            <td class="p-3 text-slate-300">\${o[10]}</td>
            <td class="p-3">
              <span class="px-2 py-0.5 rounded-full text-[10px] font-bold \${statusColor}">\${o[11]}</span>
            </td>
            <td class="p-3 text-slate-300">
              <div>\${o[13]}</div>
              <div class="text-[10px] text-slate-400">\${o[14]}, \${o[12]}</div>
            </td>
            <td class="p-3 text-center">
              \${o[15] >= 0 ? \`
                <span class="inline-flex items-center gap-1 text-[11px] \${isLate ? 'text-rose-400 font-semibold' : 'text-emerald-400'}">
                  \${isLate ? '⚠️ +' + o[16] + 'd late' : '✓ ' + o[15] + 'd on-time'}
                </span>
              \` : '<span class="text-slate-500">-</span>'}
            </td>
            <td class="p-3 text-center">
              <button onclick="event.stopPropagation(); openOrderDetail(\${globalIdx})" class="px-2 py-1 rounded bg-slate-800 hover:bg-amz-orange hover:text-black text-slate-300 text-[10px] font-semibold transition">
                View
              </button>
            </td>
          </tr>
        \`;
      });

      tbody.innerHTML = html;
    }

    // Export Filtered CSV
    function exportFilteredCSV() {
      if (filteredOrders.length === 0) {
        alert('No data to export with the current filter selection.');
        return;
      }
      const headers = ['OrderID','OrderDate','ProductName','Category','Subcategory','Quantity','UnitPriceINR','DiscountINR','ShippingFeeINR','SalesINR','PaymentMethod','OrderStatus','Region','City','State','DeliveryDays','LateDays','Quarter','MonthNum','CustomerSegment','CustomerName'];
      let csv = headers.join(',') + '\\n';

      filteredOrders.forEach(row => {
        const escaped = row.map(val => {
          if (typeof val === 'string' && (val.includes(',') || val.includes('"') || val.includes('\\n'))) {
            return '"' + val.replace(/"/g, '""') + '"';
          }
          return val;
        });
        csv += escaped.join(',') + '\\n';
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', \`Amazon_Sales_Filtered_\${new Date().toISOString().split('T')[0]}.csv\`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    // Initialize application on load
    window.addEventListener('DOMContentLoaded', () => {
      initCharts();
      updateUI();
    });
  </script>
</body>
</html>
`;

fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\amazon-sales-dashboard\\index.html', htmlTemplate, 'utf8');
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\amazon_sales_dashboard.html', htmlTemplate, 'utf8');
console.log('Successfully created index.html and amazon_sales_dashboard.html!');
