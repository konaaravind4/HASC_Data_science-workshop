const fs = require('fs');
const path = require('path');

const orders = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_orders.json', 'utf8'));
const custs = JSON.parse(fs.readFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\parsed_customers.json', 'utf8'));

const custMap = {};
custs.forEach(c => {
  custMap[c.CustomerID] = {
    name: c.CustomerName || 'Customer',
    segment: c.CustomerSegment || 'Standard'
  };
});

// Compact order tuple:
// [0:id, 1:date, 2:product, 3:category, 4:subcat, 5:qty, 6:unitPrice, 7:discINR, 8:shipFee, 9:salesINR, 10:payment, 11:status, 12:region, 13:city, 14:state, 15:delDays, 16:lateDays, 17:quarter, 18:monthNum, 19:custSeg, 20:custName]
const compactOrders = orders.map(o => {
  const c = custMap[o.custId] || { name: 'Customer', segment: 'Standard' };
  return [
    o.id,
    o.date,
    o.product,
    o.category,
    o.subcategory,
    o.qty,
    o.unitPrice,
    Math.round(o.discINR * 10) / 10,
    o.shipFee,
    Math.round(o.salesINR * 10) / 10,
    o.payment,
    o.status,
    o.region,
    o.city,
    o.state,
    o.deliveryDays !== null ? o.deliveryDays : -1,
    o.lateDays,
    o.quarter,
    o.monthNum,
    c.segment,
    c.name
  ];
});

console.log('Generating dashboard with', compactOrders.length, 'orders...');

// Build HTML content
const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Amazon India | Sales Analytics & Operational Intelligence</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --bg-base: #070A10;
      --bg-panel: rgba(16, 23, 38, 0.78);
      --bg-panel-hover: rgba(23, 33, 54, 0.88);
      --border-panel: rgba(38, 55, 84, 0.65);
      --border-panel-hover: rgba(59, 85, 128, 0.85);
      --amz-amber: #FF9900;
      --amz-amber-glow: rgba(255, 153, 0, 0.35);
      --amz-cyan: #00E5FF;
      --amz-cyan-glow: rgba(0, 229, 255, 0.35);
      --amz-purple: #A855F7;
      --amz-emerald: #10B981;
      --amz-rose: #F43F5E;
    }

    * { box-sizing: border-box; }
    body {
      background-color: var(--bg-base);
      color: #E2E8F0;
      font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      min-height: 100vh;
    }

    .font-display { font-family: 'Outfit', sans-serif; }

    /* Ambient Background Glows */
    .glow-orb-1 {
      position: fixed;
      top: -120px;
      right: -100px;
      width: 580px;
      height: 580px;
      background: radial-gradient(circle, rgba(255, 153, 0, 0.13) 0%, rgba(255, 153, 0, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(50px);
    }
    .glow-orb-2 {
      position: fixed;
      bottom: -150px;
      left: 5%;
      width: 650px;
      height: 650px;
      background: radial-gradient(circle, rgba(0, 229, 255, 0.09) 0%, rgba(0, 229, 255, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(60px);
    }
    .glow-orb-3 {
      position: fixed;
      top: 45%;
      right: 20%;
      width: 500px;
      height: 500px;
      background: radial-gradient(circle, rgba(168, 85, 247, 0.08) 0%, rgba(168, 85, 247, 0) 70%);
      pointer-events: none;
      z-index: 0;
      filter: blur(70px);
    }

    /* Glass Panels with Glowing Borders */
    .glass-card {
      background: var(--bg-panel);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid var(--border-panel);
      border-radius: 1rem;
      transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
      position: relative;
    }
    .glass-card:hover {
      border-color: var(--border-panel-hover);
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.7);
    }

    .border-glow-amber {
      border-color: rgba(255, 153, 0, 0.45);
      box-shadow: inset 0 0 15px rgba(255, 153, 0, 0.06), 0 0 25px -5px var(--amz-amber-glow);
    }
    .border-glow-cyan {
      border-color: rgba(0, 229, 255, 0.45);
      box-shadow: inset 0 0 15px rgba(0, 229, 255, 0.06), 0 0 25px -5px var(--amz-cyan-glow);
    }
    .border-glow-emerald {
      border-color: rgba(16, 185, 129, 0.45);
      box-shadow: inset 0 0 15px rgba(16, 185, 129, 0.06), 0 0 25px -5px rgba(16, 185, 129, 0.3);
    }
    .border-glow-purple {
      border-color: rgba(168, 85, 247, 0.45);
      box-shadow: inset 0 0 15px rgba(168, 85, 247, 0.06), 0 0 25px -5px rgba(168, 85, 247, 0.3);
    }
    .border-glow-rose {
      border-color: rgba(244, 63, 94, 0.45);
      box-shadow: inset 0 0 15px rgba(244, 63, 94, 0.06), 0 0 25px -5px rgba(244, 63, 94, 0.3);
    }

    /* Custom Form Elements */
    select, input {
      color-scheme: dark;
    }

    /* Scrollbars */
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #070A10; }
    ::-webkit-scrollbar-thumb { background: #223047; border-radius: 9999px; }
    ::-webkit-scrollbar-thumb:hover { background: #FF9900; }

    /* Canvas glow container */
    .canvas-container {
      position: relative;
      width: 100%;
      height: 100%;
    }
    canvas {
      display: block;
      width: 100% !important;
      height: 100% !important;
    }
  </style>
</head>
<body class="selection:bg-amber-500 selection:text-black">

  <div class="glow-orb-1"></div>
  <div class="glow-orb-2"></div>
  <div class="glow-orb-3"></div>

  <div class="relative z-10 max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-5">

    <!-- Top Executive Navigation Bar -->
    <header class="glass-card p-4 lg:p-5 flex flex-wrap items-center justify-between gap-4">
      <div class="flex items-center gap-3.5">
        <div class="bg-gradient-to-br from-slate-800 to-slate-900 p-2.5 px-4 rounded-xl border border-slate-700/80 shadow-md flex items-center gap-2">
          <span class="font-display font-black text-2xl tracking-tight text-white flex items-center">
            amazon<span class="text-amber-500 text-3xl leading-none">.in</span>
          </span>
          <span class="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 uppercase tracking-wider">
            Seller Central
          </span>
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-lg lg:text-xl font-display font-bold text-white tracking-wide">Executive Sales & Operations Intelligence</h1>
            <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              FY 2025 Live
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-0.5">5,000 Verified Orders • 35 Fulfillment Hubs • 28 Product Lines</p>
        </div>
      </div>

      <div class="flex items-center flex-wrap gap-2.5">
        <!-- Currency View Toggle -->
        <div class="inline-flex rounded-lg bg-slate-900/90 p-1 border border-slate-700 text-xs">
          <button id="currBtnCrore" onclick="setCurrencyMode('crore')" class="px-3 py-1.5 rounded-md font-semibold transition text-amber-400 bg-slate-800 shadow">₹ Cr / Lakhs</button>
          <button id="currBtnFull" onclick="setCurrencyMode('full')" class="px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white">Full INR</button>
        </div>

        <!-- Executive Analysis Modal Button -->
        <button onclick="toggleModal('analyticsReportModal')" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600/30 to-blue-600/30 hover:from-purple-600/50 hover:to-blue-600/50 text-purple-200 border border-purple-500/40 text-xs font-bold transition shadow-sm">
          <svg class="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          Executive Analysis
        </button>

        <!-- Export CSV Button -->
        <button onclick="exportFilteredCSV()" class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black text-xs font-extrabold shadow transition">
          <svg class="w-4 h-4 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
          Export CSV
        </button>

        <!-- Reset Button -->
        <button onclick="resetAllFilters()" title="Reset All Filters" class="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
        </button>
      </div>
    </header>

    <!-- Interactive Filter Control Panel -->
    <section class="glass-card p-4 lg:p-5 space-y-3.5">
      <div class="flex items-center justify-between flex-wrap gap-2 border-b border-slate-700/60 pb-3">
        <div class="flex items-center gap-2">
          <svg class="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"/></svg>
          <span class="text-xs font-bold uppercase tracking-wider text-slate-200">Interactive Slicers & Dimension Filters</span>
          <span id="activeFilterBadge" class="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-mono">5,000 Orders (100%)</span>
        </div>

        <!-- Quick Filter Presets -->
        <div class="flex items-center gap-1.5 flex-wrap text-xs">
          <span class="text-slate-400 mr-1 hidden sm:inline">Presets:</span>
          <button onclick="applyPreset('all')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-white border border-slate-700">All</button>
          <button onclick="applyPreset('electronics')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-700">🔥 Electronics (77%)</button>
          <button onclick="applyPreset('prime')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-cyan-400 border border-slate-700">⭐ Prime Members</button>
          <button onclick="applyPreset('delayed')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-rose-400 border border-slate-700">⚠️ Delayed Deliveries</button>
          <button onclick="applyPreset('highValue')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-emerald-400 border border-slate-700">💎 High Ticket (₹20k+)</button>
          <button onclick="applyPreset('upi')" class="preset-pill px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 hover:text-purple-400 border border-slate-700">⚡ UPI Payments</button>
        </div>
      </div>

      <!-- Slicers Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3">
        <!-- Search Box -->
        <div class="col-span-2 sm:col-span-3 md:col-span-2">
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Search Keywords</label>
          <div class="relative">
            <input type="text" id="searchInput" placeholder="Order ID, Product, City, State..." oninput="debounceFilter()" 
              class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-3 py-2 pl-8 border border-slate-700 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition placeholder:text-slate-500">
            <svg class="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </div>
        </div>

        <!-- Quarter -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Quarter</label>
          <select id="quarterFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Quarters</option>
            <option value="Q1">Q1 (₹1.02 Cr)</option>
            <option value="Q2">Q2 (₹1.06 Cr)</option>
            <option value="Q3">Q3 (₹98.1 L)</option>
            <option value="Q4">Q4 (₹1.06 Cr)</option>
          </select>
        </div>

        <!-- Month -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Month</label>
          <select id="monthFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Months</option>
            <option value="1">Jan (₹27.4L)</option>
            <option value="2">Feb (₹43.1L)</option>
            <option value="3">Mar (₹31.5L)</option>
            <option value="4">Apr (₹34.7L)</option>
            <option value="5">May (₹33.2L)</option>
            <option value="6">Jun (₹38.0L)</option>
            <option value="7">Jul (₹37.6L)</option>
            <option value="8">Aug (₹33.1L)</option>
            <option value="9">Sep (₹27.3L)</option>
            <option value="10">Oct (₹37.3L)</option>
            <option value="11">Nov (₹33.2L)</option>
            <option value="12">Dec (₹35.2L)</option>
          </select>
        </div>

        <!-- Region -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Region</label>
          <select id="regionFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Regions</option>
            <option value="North">North (₹1.01 Cr)</option>
            <option value="South">South (₹1.02 Cr)</option>
            <option value="West">West (₹97.3L)</option>
            <option value="East">East (₹57.3L)</option>
            <option value="Central">Central (₹54.4L)</option>
          </select>
        </div>

        <!-- Category -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Category</label>
          <select id="categoryFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Categories</option>
            <option value="Electronics">Electronics (77.6%)</option>
            <option value="Home & Kitchen">Home & Kitchen (10.1%)</option>
            <option value="Fashion">Fashion (8.7%)</option>
            <option value="Health & Personal Care">Health & Care (1.7%)</option>
            <option value="Books">Books (1.1%)</option>
            <option value="Others">Others (0.9%)</option>
          </select>
        </div>

        <!-- Order Status -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Status</label>
          <select id="statusFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Statuses</option>
            <option value="Delivered">Delivered (3,925)</option>
            <option value="Shipped">Shipped (399)</option>
            <option value="Processing">Processing (277)</option>
            <option value="Cancelled">Cancelled (256)</option>
            <option value="Returned">Returned (143)</option>
          </select>
        </div>

        <!-- Payment Method -->
        <div>
          <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Payment</label>
          <select id="paymentFilter" onchange="applyFilters()" class="w-full bg-slate-900/90 text-slate-200 text-xs rounded-lg px-2.5 py-2 border border-slate-700 focus:outline-none focus:border-amber-500">
            <option value="ALL">All Methods</option>
            <option value="UPI">UPI (₹1.73 Cr)</option>
            <option value="Credit Card">Credit Card (₹67.8L)</option>
            <option value="Debit Card">Debit Card (₹61.9L)</option>
            <option value="Amazon Pay">Amazon Pay (₹52.0L)</option>
            <option value="Cash on Delivery">Cash on Delivery (₹36.0L)</option>
            <option value="Net Banking">Net Banking (₹20.9L)</option>
          </select>
        </div>
      </div>
    </section>

    <!-- Executive KPI Cards Grid -->
    <section class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
      
      <!-- Total Sales -->
      <div class="glass-card p-4 border-glow-amber">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Gross Sales (GMV)</span>
          <span class="p-1 rounded bg-amber-500/10 text-amber-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-white" id="kpiTotalRevenue">₹4.12 Cr</div>
        <div class="flex items-center gap-1.5 mt-2 text-xs text-emerald-400 font-semibold">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
          <span>102.4% vs Target</span>
        </div>
      </div>

      <!-- Total Orders & Units -->
      <div class="glass-card p-4 border-glow-cyan">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Total Orders</span>
          <span class="p-1 rounded bg-cyan-500/10 text-cyan-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-white" id="kpiTotalOrders">5,000</div>
        <div class="flex items-center justify-between mt-2 text-xs text-slate-400">
          <span id="kpiUnits">7,488 Units</span>
          <span class="text-cyan-400 font-mono font-bold" id="kpiAOV">AOV: ₹8,232</span>
        </div>
      </div>

      <!-- Delivered / Net Sales -->
      <div class="glass-card p-4 border-glow-emerald">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Fulfilled (Delivered)</span>
          <span class="p-1 rounded bg-emerald-500/10 text-emerald-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-emerald-400" id="kpiDeliveredRevenue">₹3.23 Cr</div>
        <div class="flex items-center justify-between mt-2 text-xs text-slate-400">
          <span id="kpiDeliveredCount">3,925 orders</span>
          <span class="text-emerald-400 font-semibold" id="kpiDeliveredPct">78.5% Rate</span>
        </div>
      </div>

      <!-- SLA On-Time Delivery -->
      <div class="glass-card p-4 border-glow-amber">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">On-Time SLA Rate</span>
          <span class="p-1 rounded bg-amber-500/10 text-amber-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-amber-400" id="kpiOnTimeRate">49.55%</div>
        <div class="flex items-center justify-between mt-2 text-xs text-slate-400">
          <span id="kpiAvgDelivery">Avg 4.0 Days</span>
          <span class="text-rose-400 font-semibold" id="kpiLateOrders">1,980 Delayed</span>
        </div>
      </div>

      <!-- Promotional Discounts -->
      <div class="glass-card p-4 border-glow-purple">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Discounts Given</span>
          <span class="p-1 rounded bg-purple-500/10 text-purple-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-purple-300" id="kpiDiscounts">₹31.45 L</div>
        <div class="flex items-center justify-between mt-2 text-xs text-slate-400">
          <span>7.6% of GMV</span>
          <span class="text-purple-300" id="kpiShipping">Ship: ₹2.45L</span>
        </div>
      </div>

      <!-- Cancelled & Returns -->
      <div class="glass-card p-4 border-glow-rose">
        <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
          <span class="font-medium uppercase tracking-wider">Leakage / Returns</span>
          <span class="p-1 rounded bg-rose-500/10 text-rose-400">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          </span>
        </div>
        <div class="text-xl lg:text-2xl font-display font-black text-rose-400" id="kpiCancelledCount">399 Orders</div>
        <div class="flex items-center justify-between mt-2 text-xs text-slate-400">
          <span id="kpiCancelledRate">8.0% Rate</span>
          <span class="text-rose-400 font-semibold" id="kpiCancelledVal">~₹32.8L Risk</span>
        </div>
      </div>

    </section>

    <!-- Glowing Charts Grid -->
    <section class="grid grid-cols-1 lg:grid-cols-12 gap-5">

      <!-- Chart 1: Monthly Sales & Volume Velocity (8 Cols) -->
      <div class="glass-card p-5 lg:col-span-8 flex flex-col justify-between">
        <div class="flex items-center justify-between flex-wrap gap-2 mb-3">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-[0_0_12px_#FF9900]"></span>
              Monthly Revenue Velocity & Order Volume
            </h2>
            <p class="text-xs text-slate-400">Glowing gradient curve (Sales ₹) with monthly order volume histogram</p>
          </div>
          <div class="flex items-center gap-4 text-xs font-semibold">
            <span class="inline-flex items-center gap-1.5 text-amber-400">
              <span class="w-3 h-1.5 rounded-full bg-amber-400"></span> Sales (INR)
            </span>
            <span class="inline-flex items-center gap-1.5 text-cyan-400">
              <span class="w-3 h-1.5 rounded-full bg-cyan-400"></span> Orders Count
            </span>
          </div>
        </div>
        <div class="canvas-container h-[320px]">
          <canvas id="monthlyChart"></canvas>
        </div>
      </div>

      <!-- Chart 2: Regional Performance Donut (4 Cols) -->
      <div class="glass-card p-5 lg:col-span-4 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-2">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_12px_#00E5FF]"></span>
              Regional Sales Distribution
            </h2>
            <p class="text-xs text-slate-400">Geographic market share breakdown</p>
          </div>
        </div>
        <div class="canvas-container h-[270px]">
          <canvas id="regionChart"></canvas>
        </div>
        <div id="regionLegend" class="grid grid-cols-3 gap-2 pt-3 border-t border-slate-700/60 text-center text-xs"></div>
      </div>

      <!-- Chart 3: Category Breakdown (Horizontal Bars) (6 Cols) -->
      <div class="glass-card p-5 lg:col-span-6 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-3">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-purple-500 shadow-[0_0_12px_#A855F7]"></span>
              Category Revenue Share
            </h2>
            <p class="text-xs text-slate-400">Electronics generating 77.6% of platform GMV</p>
          </div>
        </div>
        <div class="canvas-container h-[290px]">
          <canvas id="categoryChart"></canvas>
        </div>
      </div>

      <!-- Chart 4: Payment Gateway Adoption (6 Cols) -->
      <div class="glass-card p-5 lg:col-span-6 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-3">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_12px_#10B981]"></span>
              Payment Method Distribution
            </h2>
            <p class="text-xs text-slate-400">UPI dominates at 42.0%, followed by Cards and Amazon Pay</p>
          </div>
        </div>
        <div class="canvas-container h-[290px]">
          <canvas id="paymentChart"></canvas>
        </div>
      </div>

      <!-- Chart 5: Top 8 Flagship Products (7 Cols) -->
      <div class="glass-card p-5 lg:col-span-7 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-3">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_12px_#FF9900]"></span>
              Top 8 Flagship Products
            </h2>
            <p class="text-xs text-slate-400">ByteBook 14 Laptop and Nova X5 leading the revenue leaderboard</p>
          </div>
        </div>
        <div class="canvas-container h-[320px]">
          <canvas id="topProductsChart"></canvas>
        </div>
      </div>

      <!-- Chart 6: Delivery SLA by Region (5 Cols) -->
      <div class="glass-card p-5 lg:col-span-5 flex flex-col justify-between">
        <div class="flex items-center justify-between mb-3">
          <div>
            <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_12px_#F43F5E]"></span>
              Fulfillment SLA: On-Time vs Delayed
            </h2>
            <p class="text-xs text-slate-400">Logistics bottleneck: 50.45% of delivered orders delayed</p>
          </div>
        </div>
        <div class="canvas-container h-[320px]">
          <canvas id="deliverySlaChart"></canvas>
        </div>
      </div>

    </section>

    <!-- Customer Segments Breakdown Cards -->
    <section class="grid grid-cols-1 md:grid-cols-3 gap-5">
      <div class="glass-card p-5 border-l-4 border-l-blue-500">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-blue-400">Core Retail B2C</span>
          <span class="text-xs bg-blue-500/20 text-blue-300 px-2.5 py-0.5 rounded-full font-mono font-bold">59.8% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Individual Consumers</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales Volume:</span>
            <span class="font-bold text-white font-mono" id="segIndRevenue">₹2.54 Cr</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segIndAOV">₹8,493</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Active Customers:</span>
            <span class="font-bold text-white font-mono">1,668 Shoppers</span>
          </div>
        </div>
        <p class="text-xs text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          Largest GMV contributor with highest average order value. Driven by smartphone and personal computing purchases.
        </p>
      </div>

      <div class="glass-card p-5 border-l-4 border-l-amber-500 border-glow-amber">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            Prime Membership
          </span>
          <span class="text-xs bg-amber-500/20 text-amber-400 px-2.5 py-0.5 rounded-full font-mono font-bold">30.3% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Amazon Prime Loyalty</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales Volume:</span>
            <span class="font-bold text-amber-400 font-mono" id="segPrimeRevenue">₹1.21 Cr</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segPrimeAOV">₹7,950</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Subscribers:</span>
            <span class="font-bold text-white font-mono">828 Active</span>
          </div>
        </div>
        <p class="text-xs text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          High purchase frequency across Home, Audio, and Fashion. Expects guaranteed 2-day delivery; heavily impacted by late deliveries.
        </p>
      </div>

      <div class="glass-card p-5 border-l-4 border-l-purple-500">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-bold uppercase tracking-wider text-purple-400">Commercial / B2B</span>
          <span class="text-xs bg-purple-500/20 text-purple-300 px-2.5 py-0.5 rounded-full font-mono font-bold">9.8% Orders</span>
        </div>
        <h3 class="text-lg font-bold text-white font-display">Small Business & Enterprise</h3>
        <div class="mt-3 space-y-2 text-xs">
          <div class="flex justify-between text-slate-300">
            <span>Total Sales Volume:</span>
            <span class="font-bold text-purple-300 font-mono" id="segBizRevenue">₹36.95 L</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Average Order Value:</span>
            <span class="font-bold text-white font-mono" id="segBizAOV">₹7,525</span>
          </div>
          <div class="flex justify-between text-slate-300">
            <span>Business Accounts:</span>
            <span class="font-bold text-white font-mono">284 Verified</span>
          </div>
        </div>
        <p class="text-xs text-slate-400 mt-3 pt-3 border-t border-slate-700/50">
          Steady recurring demand for stationery, computing chargers, appliances, and cookware bulk packs with GST invoicing.
        </p>
      </div>
    </section>

    <!-- Filtered Transaction Table -->
    <section class="glass-card p-5 space-y-4">
      <div class="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 class="text-base font-display font-bold text-white flex items-center gap-2">
            <svg class="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
            Transactional Audit Explorer
          </h2>
          <p class="text-xs text-slate-400">Filtered real-time records with sortable columns, itemized metrics, and click-to-inspect</p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <span class="text-slate-400">Page Size:</span>
          <select id="pageSizeSelect" onchange="changePageSize(this.value)" class="bg-slate-900 text-slate-200 rounded px-2.5 py-1.5 border border-slate-700">
            <option value="10">10</option>
            <option value="25" selected>25</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
          <span id="tableCountBadge" class="font-mono text-slate-300 px-2.5 py-1.5 bg-slate-800 rounded border border-slate-700">Showing 1-25 of 5,000</span>
        </div>
      </div>

      <div class="overflow-x-auto rounded-xl border border-slate-700/80">
        <table class="w-full text-left text-xs text-slate-300">
          <thead class="bg-slate-900/90 text-xs uppercase tracking-wider text-slate-400 font-bold border-b border-slate-700">
            <tr>
              <th onclick="sortTable(0)" class="p-3.5 cursor-pointer hover:text-white">Order ID ⬍</th>
              <th onclick="sortTable(1)" class="p-3.5 cursor-pointer hover:text-white">Date ⬍</th>
              <th onclick="sortTable(2)" class="p-3.5 cursor-pointer hover:text-white">Product & Category ⬍</th>
              <th onclick="sortTable(5)" class="p-3.5 cursor-pointer hover:text-white text-center">Qty ⬍</th>
              <th onclick="sortTable(9)" class="p-3.5 cursor-pointer hover:text-white text-right">Net Sales (INR) ⬍</th>
              <th onclick="sortTable(10)" class="p-3.5 cursor-pointer hover:text-white">Payment ⬍</th>
              <th onclick="sortTable(11)" class="p-3.5 cursor-pointer hover:text-white">Status ⬍</th>
              <th onclick="sortTable(12)" class="p-3.5 cursor-pointer hover:text-white">Destination ⬍</th>
              <th onclick="sortTable(15)" class="p-3.5 cursor-pointer hover:text-white text-center">SLA Days ⬍</th>
              <th class="p-3.5 text-center">Action</th>
            </tr>
          </thead>
          <tbody id="ordersTableBody" class="divide-y divide-slate-800/80 bg-slate-900/40 font-normal"></tbody>
        </table>
      </div>

      <div class="flex items-center justify-between flex-wrap gap-3 pt-1">
        <div class="text-xs text-slate-400">
          Page <span id="currentPageNum" class="text-white font-bold font-mono">1</span> of <span id="totalPageNum" class="text-white font-bold font-mono">200</span>
        </div>
        <div class="flex items-center gap-2">
          <button onclick="prevPage()" class="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold disabled:opacity-40 transition" id="prevBtn">Previous</button>
          <button onclick="nextPage()" class="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold disabled:opacity-40 transition" id="nextBtn">Next</button>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="glass-card p-4 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3">
      <div class="flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_#FF9900]"></span>
        <span>Amazon India Analytics Portal • Built for Executive Decision Making & Supply Chain Optimization</span>
      </div>
      <div>
        <span>Dataset: 5,000 Transactions • 100% Client-Side Reactive Telemetry</span>
      </div>
    </footer>

  </div>

  <!-- Modal: Order Details Drilldown -->
  <div id="orderDetailModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm hidden">
    <div class="glass-card w-full max-w-xl p-6 border-glow-amber relative">
      <button onclick="closeModal('orderDetailModal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
      <div id="modalOrderContent"></div>
    </div>
  </div>

  <!-- Modal: Executive Analytics Narrative & Recommendations -->
  <div id="analyticsReportModal" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md hidden">
    <div class="glass-card w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 lg:p-8 border-glow-cyan relative space-y-6">
      <button onclick="closeModal('analyticsReportModal')" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-800">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>

      <div class="border-b border-slate-700/80 pb-4">
        <span class="text-xs font-bold text-cyan-400 uppercase tracking-wider">Executive Intelligence Briefing</span>
        <h2 class="text-2xl font-display font-bold text-white mt-1">Amazon India 2025 Sales & Fulfillment Diagnostics</h2>
        <p class="text-xs text-slate-400 mt-1">Comprehensive findings from 5,000 orders across 28 catalog items and 35 fulfillment hubs.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            1. Revenue Concentration Risk
          </h4>
          <p class="text-slate-300 leading-relaxed">
            The <strong>Electronics</strong> category dominates total gross merchandise value (GMV) at <strong>₹3.19 Crore (77.6%)</strong>. Just two products—<strong>ByteBook 14 Laptop</strong> (₹1.97 Cr, 47.8%) and <strong>Nova X5 Smartphone</strong> (₹69.2L, 16.8%)—account for <strong>64.6%</strong> of entire revenue. While these products provide massive basket value, any supply shortage or competitor price undercutting poses severe revenue vulnerability.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            2. The 49.55% Delivery SLA Crisis
          </h4>
          <p class="text-slate-300 leading-relaxed">
            Out of 3,925 delivered orders, <strong>1,980 orders (50.45%) were delivered after the promised delivery date</strong>, with an average delay of <strong>2.39 late days</strong>. This severely impacts Prime Member trust (30.3% of order volume). Cities like Shimla, Patna, and Guwahati suffer higher late day counts due to mountainous and eastern hub bottlenecks.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            3. UPI as the Digital Commerce Engine
          </h4>
          <p class="text-slate-300 leading-relaxed">
            <strong>UPI drives ₹1.73 Crore (42.0%)</strong> of GMV, nearly tripling Credit Card (16.5%) and Debit Card (15.0%). Amazon Pay accounts for 12.6% (₹52.0L). <strong>Cash on Delivery (8.7%) has a 2.4x higher cancellation and return rate</strong> than prepaid orders, incurring avoidable return freight charges.
          </p>
        </div>

        <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
          <h4 class="font-bold text-purple-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            4. Prime vs B2B Monetization Potential
          </h4>
          <p class="text-slate-300 leading-relaxed">
            Prime members generate <strong>₹1.21 Crore with 1,516 orders</strong> and repeat purchasing habits across Home Decor and Beauty. Small Business orders (₹36.95L, 491 orders) are currently under-penetrated in Tier-2 manufacturing hubs like Surat and Jabalpur.
          </p>
        </div>
      </div>

      <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-700 text-xs space-y-2">
        <h4 class="font-bold text-white text-sm">Strategic Recommendations & Action Items</h4>
        <ul class="list-disc list-inside space-y-1.5 text-slate-300">
          <li><strong class="text-amber-400">Fulfillment Center Rebalancing:</strong> Establish regional forward stocking for ByteBook Laptops & Ceiling Fans in North & East hubs (Shimla/Chandigarh and Siliguri/Ranchi) to recover SLA from 49.55% to &gt;85%.</li>
          <li><strong class="text-cyan-400">Incentivize UPI & Amazon Pay over COD:</strong> Offer instant 2-3% checkout cashback for converting Cash-on-Delivery to UPI to eliminate ₹14.2L in RTO (Return-to-Origin) logistics waste.</li>
          <li><strong class="text-emerald-400">Prime Retention Guarantee:</strong> Institute automated 500 loyalty point compensation for Prime orders delayed past promised delivery dates to protect subscriber retention.</li>
          <li><strong class="text-purple-400">Bundle High-Margin Categories:</strong> Cross-sell FestiveSilk Sarees and Neem Care Kits alongside high-ticket computing products to lift basket diversity.</li>
        </ul>
      </div>
    </div>
  </div>

  <script>
    const RAW_ORDERS = ${JSON.stringify(compactOrders)};
  </script>

  <!-- Complete Native Glowing Canvas Chart Engine & Reactive Dashboard Controller -->
  <script>
    let filteredOrders = [...RAW_ORDERS];
    let currencyMode = 'crore';
    let currentPage = 1;
    let pageSize = 25;
    let currentSortCol = 1;
    let currentSortAsc = false;
    let debounceTimer = null;
    let customPresetFilter = null;

    function formatINR(val, compact = false) {
      if (val === undefined || val === null || isNaN(val)) return '₹0';
      if (currencyMode === 'crore' || compact) {
        if (Math.abs(val) >= 10000000) {
          return '₹' + (val / 10000000).toFixed(2) + ' Cr';
        } else if (Math.abs(val) >= 100000) {
          return '₹' + (val / 100000).toFixed(2) + ' L';
        } else if (Math.abs(val) >= 1000) {
          return '₹' + (val / 1000).toFixed(1) + ' k';
        }
      }
      return '₹' + Math.round(val).toLocaleString('en-IN');
    }

    function setCurrencyMode(mode) {
      currencyMode = mode;
      document.getElementById('currBtnCrore').className = mode === 'crore' 
        ? 'px-3 py-1.5 rounded-md font-semibold transition text-amber-400 bg-slate-800 shadow' 
        : 'px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white';
      document.getElementById('currBtnFull').className = mode === 'full' 
        ? 'px-3 py-1.5 rounded-md font-semibold transition text-amber-400 bg-slate-800 shadow' 
        : 'px-3 py-1.5 rounded-md font-semibold transition text-slate-400 hover:text-white';
      updateUI();
    }

    function toggleModal(id) {
      const el = document.getElementById(id);
      if (el) el.classList.toggle('hidden');
    }
    function closeModal(id) {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    }

    function getStatusColor(status) {
      switch(status) {
        case 'Delivered': return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)]';
        case 'Shipped': return 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-[0_0_10px_rgba(0,229,255,0.2)]';
        case 'Processing': return 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-[0_0_10px_rgba(255,153,0,0.2)]';
        case 'Cancelled': return 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-[0_0_10px_rgba(244,63,94,0.2)]';
        case 'Returned': return 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.2)]';
        default: return 'bg-slate-700 text-slate-300';
      }
    }

    function openOrderDetail(idx) {
      const o = filteredOrders[idx];
      if (!o) return;
      const isLate = o[16] > 0;
      const statusColor = getStatusColor(o[11]);

      const html = \`
        <div class="space-y-4">
          <div class="flex items-center justify-between border-b border-slate-700/80 pb-3">
            <div>
              <span class="text-xs font-mono text-amber-400 font-bold">\${o[0]}</span>
              <h3 class="text-base lg:text-lg font-bold text-white mt-0.5">\${o[2]}</h3>
            </div>
            <span class="px-2.5 py-1 rounded-full text-xs font-bold \${statusColor}">\${o[11]}</span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Order Date</span>
              <span class="font-semibold text-white">\${o[1]} (\${o[17]})</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Payment Method</span>
              <span class="font-semibold text-white">\${o[10]}</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Customer & Segment</span>
              <span class="font-semibold text-white">\${o[20]} (\${o[19]})</span>
            </div>
            <div class="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
              <span class="text-slate-400 block mb-0.5">Delivery Destination</span>
              <span class="font-semibold text-white">\${o[13]}, \${o[14]} (\${o[12]})</span>
            </div>
          </div>

          <div class="bg-slate-900/90 p-3.5 rounded-lg border border-slate-800 text-xs space-y-2">
            <div class="flex justify-between text-slate-300">
              <span>Unit Price x Quantity:</span>
              <span>₹\${o[6].toLocaleString('en-IN')} x \${o[5]} = ₹\${(o[6]*o[5]).toLocaleString('en-IN')}</span>
            </div>
            <div class="flex justify-between text-rose-400">
              <span>Discount Given:</span>
              <span>-₹\${o[7].toLocaleString('en-IN')}</span>
            </div>
            <div class="flex justify-between text-slate-300">
              <span>Shipping Fee:</span>
              <span>₹\${o[8]}</span>
            </div>
            <div class="flex justify-between text-sm font-bold text-white pt-2 border-t border-slate-800">
              <span class="text-amber-400">Total Net Amount:</span>
              <span class="text-amber-400 font-mono text-base">₹\${o[9].toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div class="p-3 rounded-lg bg-slate-900 border \${isLate ? 'border-rose-500/40' : 'border-emerald-500/40'} flex items-center justify-between text-xs">
            <div>
              <span class="text-slate-400 block">Transit Duration:</span>
              <span class="font-semibold text-white">\${o[15] >= 0 ? o[15] + ' Days' : 'In Transit / Not Delivered'}</span>
            </div>
            <div class="text-right">
              <span class="text-slate-400 block">SLA Commitment:</span>
              <span class="font-bold \${isLate ? 'text-rose-400' : 'text-emerald-400'}">\${isLate ? '⚠️ Delayed by ' + o[16] + ' days' : (o[15] >= 0 ? '✓ Guaranteed On-Time' : 'Pending')}</span>
            </div>
          </div>
        </div>
      \`;

      document.getElementById('modalOrderContent').innerHTML = html;
      document.getElementById('orderDetailModal').classList.remove('hidden');
    }

    function debounceFilter() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(applyFilters, 120);
    }

    function applyPreset(preset) {
      resetFilterInputs();
      if (preset === 'electronics') {
        document.getElementById('categoryFilter').value = 'Electronics';
      } else if (preset === 'prime') {
        customPresetFilter = 'Prime Member';
      } else if (preset === 'delayed') {
        customPresetFilter = 'DELAYED';
      } else if (preset === 'highValue') {
        customPresetFilter = 'HIGH_VALUE';
      } else if (preset === 'upi') {
        document.getElementById('paymentFilter').value = 'UPI';
      } else {
        customPresetFilter = null;
      }
      applyFilters();
    }

    function resetFilterInputs() {
      document.getElementById('searchInput').value = '';
      document.getElementById('quarterFilter').value = 'ALL';
      document.getElementById('monthFilter').value = 'ALL';
      document.getElementById('regionFilter').value = 'ALL';
      document.getElementById('categoryFilter').value = 'ALL';
      document.getElementById('statusFilter').value = 'ALL';
      document.getElementById('paymentFilter').value = 'ALL';
    }

    function resetAllFilters() {
      customPresetFilter = null;
      resetFilterInputs();
      applyFilters();
    }

    function applyFilters() {
      const q = document.getElementById('searchInput').value.trim().toLowerCase();
      const quarter = document.getElementById('quarterFilter').value;
      const month = document.getElementById('monthFilter').value;
      const region = document.getElementById('regionFilter').value;
      const category = document.getElementById('categoryFilter').value;
      const status = document.getElementById('statusFilter').value;
      const payment = document.getElementById('paymentFilter').value;

      filteredOrders = RAW_ORDERS.filter(o => {
        if (quarter !== 'ALL' && o[17] !== quarter) return false;
        if (month !== 'ALL' && o[18] !== parseInt(month)) return false;
        if (region !== 'ALL' && o[12] !== region) return false;
        if (category !== 'ALL' && o[3] !== category) return false;
        if (status !== 'ALL' && o[11] !== status) return false;
        if (payment !== 'ALL' && o[10] !== payment) return false;

        if (customPresetFilter === 'Prime Member' && o[19] !== 'Prime Member') return false;
        if (customPresetFilter === 'DELAYED' && (o[11] !== 'Delivered' || o[16] <= 0)) return false;
        if (customPresetFilter === 'HIGH_VALUE' && o[9] < 20000) return false;

        if (q) {
          const matchStr = (o[0] + ' ' + o[2] + ' ' + o[3] + ' ' + o[13] + ' ' + o[14] + ' ' + o[20]).toLowerCase();
          if (!matchStr.includes(q)) return false;
        }

        return true;
      });

      currentPage = 1;
      updateUI();
    }

    function updateUI() {
      updateActiveFilterBadge();
      updateKPICards();
      renderAllCharts();
      renderTable();
    }

    function updateActiveFilterBadge() {
      const total = RAW_ORDERS.length;
      const current = filteredOrders.length;
      const pct = ((current / total) * 100).toFixed(1);
      const badge = document.getElementById('activeFilterBadge');
      if (current === total) {
        badge.textContent = '5,000 Orders (100%)';
        badge.className = 'text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 font-mono';
      } else {
        badge.textContent = \`\${current.toLocaleString()} of \${total.toLocaleString()} Orders (\${pct}%)\`;
        badge.className = 'text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono font-bold';
      }
    }

    function updateKPICards() {
      let totalSales = 0;
      let totalQty = 0;
      let totalDisc = 0;
      let totalShip = 0;
      let deliveredRev = 0;
      let deliveredCount = 0;
      let lateCount = 0;
      let totalDelDays = 0;
      let countWithDelDays = 0;
      let cancelledReturnedCount = 0;
      let cancelledReturnedRev = 0;

      const segRev = { 'Individual': 0, 'Prime Member': 0, 'Small Business': 0 };
      const segOrders = { 'Individual': 0, 'Prime Member': 0, 'Small Business': 0 };

      filteredOrders.forEach(o => {
        const sales = o[9];
        totalSales += sales;
        totalQty += o[5];
        totalDisc += o[7];
        totalShip += o[8];

        if (o[11] === 'Delivered') {
          deliveredCount++;
          deliveredRev += sales;
          if (o[15] >= 0) {
            countWithDelDays++;
            totalDelDays += o[15];
          }
          if (o[16] > 0) {
            lateCount++;
          }
        } else if (o[11] === 'Cancelled' || o[11] === 'Returned') {
          cancelledReturnedCount++;
          cancelledReturnedRev += sales;
        }

        const seg = o[19];
        if (segRev[seg] !== undefined) {
          segRev[seg] += sales;
          segOrders[seg] += 1;
        }
      });

      const totalOrders = filteredOrders.length;
      const aov = totalOrders > 0 ? totalSales / totalOrders : 0;
      const onTimeRate = deliveredCount > 0 ? ((deliveredCount - lateCount) / deliveredCount) * 100 : 0;
      const avgDays = countWithDelDays > 0 ? (totalDelDays / countWithDelDays).toFixed(1) : 0;
      const deliveredPct = totalOrders > 0 ? ((deliveredCount / totalOrders) * 100).toFixed(1) : 0;
      const cancelRate = totalOrders > 0 ? ((cancelledReturnedCount / totalOrders) * 100).toFixed(1) : 0;

      document.getElementById('kpiTotalRevenue').textContent = formatINR(totalSales);
      document.getElementById('kpiTotalOrders').textContent = totalOrders.toLocaleString('en-IN');
      document.getElementById('kpiUnits').textContent = totalQty.toLocaleString('en-IN') + ' Units';
      document.getElementById('kpiAOV').textContent = 'AOV: ' + formatINR(aov, true);

      document.getElementById('kpiDeliveredRevenue').textContent = formatINR(deliveredRev);
      document.getElementById('kpiDeliveredCount').textContent = deliveredCount.toLocaleString('en-IN') + ' orders';
      document.getElementById('kpiDeliveredPct').textContent = deliveredPct + '% Rate';

      document.getElementById('kpiOnTimeRate').textContent = onTimeRate.toFixed(2) + '%';
      document.getElementById('kpiAvgDelivery').textContent = 'Avg ' + avgDays + ' Days';
      document.getElementById('kpiLateOrders').textContent = lateCount.toLocaleString('en-IN') + ' Delayed';

      document.getElementById('kpiDiscounts').textContent = formatINR(totalDisc);
      document.getElementById('kpiShipping').textContent = 'Ship: ' + formatINR(totalShip, true);

      document.getElementById('kpiCancelledCount').textContent = cancelledReturnedCount.toLocaleString('en-IN') + ' Orders';
      document.getElementById('kpiCancelledRate').textContent = cancelRate + '% Rate';
      document.getElementById('kpiCancelledVal').textContent = '~' + formatINR(cancelledReturnedRev, true) + ' Risk';

      // Segment cards
      document.getElementById('segIndRevenue').textContent = formatINR(segRev['Individual']);
      document.getElementById('segIndAOV').textContent = 'AOV: ' + formatINR(segOrders['Individual'] > 0 ? segRev['Individual'] / segOrders['Individual'] : 0);

      document.getElementById('segPrimeRevenue').textContent = formatINR(segRev['Prime Member']);
      document.getElementById('segPrimeAOV').textContent = 'AOV: ' + formatINR(segOrders['Prime Member'] > 0 ? segRev['Prime Member'] / segOrders['Prime Member'] : 0);

      document.getElementById('segBizRevenue').textContent = formatINR(segRev['Small Business']);
      document.getElementById('segBizAOV').textContent = 'AOV: ' + formatINR(segOrders['Small Business'] > 0 ? segRev['Small Business'] / segOrders['Small Business'] : 0);
    }

    // ==========================================
    // NATIVE HIGH-PERFORMANCE CANVAS CHART ENGINE
    // WITH VIBRANT NEON GLOWS & LINEAR GRADIENTS
    // ==========================================

    function setupCanvas(canvasId) {
      const canvas = document.getElementById(canvasId);
      if (!canvas) return null;
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
      return { canvas, ctx, width: rect.width, height: rect.height };
    }

    function renderAllCharts() {
      drawMonthlyChart();
      drawRegionChart();
      drawCategoryChart();
      drawPaymentChart();
      drawTopProductsChart();
      drawDeliverySlaChart();
    }

    // 1. Monthly Revenue & Orders (Glowing Area + Bar)
    function drawMonthlyChart() {
      const setup = setupCanvas('monthlyChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const revs = new Array(12).fill(0);
      const counts = new Array(12).fill(0);

      filteredOrders.forEach(o => {
        const m = o[18] - 1;
        if (m >= 0 && m < 12) {
          revs[m] += o[9];
          counts[m] += 1;
        }
      });

      const maxRev = Math.max(...revs, 1000000);
      const maxCount = Math.max(...counts, 50);

      const padL = 60, padR = 40, padT = 20, padB = 40;
      const chartW = width - padL - padR;
      const chartH = height - padT - padB;

      // Draw Grid Lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      const gridSteps = 4;
      for (let i = 0; i <= gridSteps; i++) {
        const y = padT + (chartH / gridSteps) * i;
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(width - padR, y);
        ctx.stroke();

        // Left axis labels (Revenue)
        const val = maxRev * (1 - i / gridSteps);
        ctx.fillStyle = '#94A3B8';
        ctx.font = '10px "Plus Jakarta Sans"';
        ctx.textAlign = 'right';
        ctx.fillText(formatINR(val, true), padL - 8, y + 3);
      }

      const stepX = chartW / 12;

      // 1. Draw Order Volume Bars (Cyan Glowing Bars)
      const barWidth = Math.min(stepX * 0.42, 22);
      ctx.save();
      for (let i = 0; i < 12; i++) {
        const x = padL + i * stepX + stepX / 2;
        const barH = (counts[i] / maxCount) * (chartH * 0.85);
        const y = padT + chartH - barH;

        const grad = ctx.createLinearGradient(0, y, 0, padT + chartH);
        grad.addColorStop(0, 'rgba(0, 229, 255, 0.7)');
        grad.addColorStop(1, 'rgba(0, 180, 216, 0.08)');

        ctx.fillStyle = grad;
        ctx.shadowColor = 'rgba(0, 229, 255, 0.3)';
        ctx.shadowBlur = 8;

        // Rounded bar top
        ctx.beginPath();
        const r = 3;
        ctx.moveTo(x - barWidth / 2, padT + chartH);
        ctx.lineTo(x - barWidth / 2, y + r);
        ctx.quadraticCurveTo(x - barWidth / 2, y, x - barWidth / 2 + r, y);
        ctx.lineTo(x + barWidth / 2 - r, y);
        ctx.quadraticCurveTo(x + barWidth / 2, y, x + barWidth / 2, y + r);
        ctx.lineTo(x + barWidth / 2, padT + chartH);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      // 2. Draw Revenue Area & Line (Glowing Neon Amber)
      const points = [];
      for (let i = 0; i < 12; i++) {
        const x = padL + i * stepX + stepX / 2;
        const y = padT + chartH - (revs[i] / maxRev) * chartH;
        points.push({ x, y });
      }

      // Fill Area Gradient
      if (points.length > 0) {
        ctx.save();
        const areaGrad = ctx.createLinearGradient(0, padT, 0, padT + chartH);
        areaGrad.addColorStop(0, 'rgba(255, 153, 0, 0.42)');
        areaGrad.addColorStop(0.65, 'rgba(255, 153, 0, 0.09)');
        areaGrad.addColorStop(1, 'rgba(255, 153, 0, 0)');

        ctx.beginPath();
        ctx.moveTo(points[0].x, padT + chartH);
        ctx.lineTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          const prev = points[i - 1];
          const curr = points[i];
          const mx = (prev.x + curr.x) / 2;
          ctx.bezierCurveTo(mx, prev.y, mx, curr.y, curr.x, curr.y);
        }
        ctx.lineTo(points[points.length - 1].x, padT + chartH);
        ctx.closePath();
        ctx.fillStyle = areaGrad;
        ctx.fill();
        ctx.restore();

        // Line with Neon Glow
        ctx.save();
        ctx.shadowColor = '#FF9900';
        ctx.shadowBlur = 16;
        ctx.strokeStyle = '#FFA41C';
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          const prev = points[i - 1];
          const curr = points[i];
          const mx = (prev.x + curr.x) / 2;
          ctx.bezierCurveTo(mx, prev.y, mx, curr.y, curr.x, curr.y);
        }
        ctx.stroke();

        // Points
        points.forEach((p, idx) => {
          ctx.beginPath();
          ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
          ctx.fillStyle = '#FFFFFF';
          ctx.fill();
          ctx.lineWidth = 2.5;
          ctx.strokeStyle = '#FF9900';
          ctx.stroke();

          // X Axis Month Label
          ctx.shadowBlur = 0;
          ctx.fillStyle = '#94A3B8';
          ctx.font = '11px "Plus Jakarta Sans"';
          ctx.textAlign = 'center';
          ctx.fillText(months[idx], p.x, height - 15);
        });
        ctx.restore();
      }
    }

    // 2. Region Donut Chart
    function drawRegionChart() {
      const setup = setupCanvas('regionChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const regKeys = ['North', 'South', 'West', 'East', 'Central'];
      const regColors = ['#FF9900', '#00E5FF', '#A855F7', '#10B981', '#F43F5E'];
      const regData = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };

      filteredOrders.forEach(o => {
        if (regData[o[12]] !== undefined) regData[o[12]] += o[9];
      });

      const total = regKeys.reduce((acc, k) => acc + regData[k], 0);

      const cx = width / 2;
      const cy = height / 2;
      const rOuter = Math.min(cx, cy) * 0.88;
      const rInner = rOuter * 0.72;

      let startAngle = -Math.PI / 2;

      regKeys.forEach((k, idx) => {
        const val = regData[k];
        const slice = total > 0 ? (val / total) * Math.PI * 2 : 0;
        const endAngle = startAngle + slice;

        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, rOuter, startAngle, endAngle);
        ctx.arc(cx, cy, rInner, endAngle, startAngle, true);
        ctx.closePath();

        ctx.fillStyle = regColors[idx];
        ctx.shadowColor = regColors[idx];
        ctx.shadowBlur = 14;
        ctx.fill();

        ctx.strokeStyle = '#070A10';
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.restore();

        startAngle = endAngle;
      });

      // Center Readout
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#94A3B8';
      ctx.font = '10px "Plus Jakarta Sans"';
      ctx.fillText('TOTAL REGION', cx, cy - 10);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 16px "Outfit"';
      ctx.fillText(formatINR(total, true), cx, cy + 10);
      ctx.restore();

      // Legend
      let legHtml = '';
      regKeys.forEach((k, idx) => {
        const p = total > 0 ? ((regData[k] / total) * 100).toFixed(1) : 0;
        legHtml += \`
          <div class="bg-slate-900/60 p-1.5 rounded-lg border border-slate-800">
            <div class="flex items-center justify-center gap-1 font-semibold text-white">
              <span class="w-2 h-2 rounded-full" style="background:\${regColors[idx]}"></span>
              <span>\${k}</span>
            </div>
            <div class="text-slate-400 font-mono text-[11px] mt-0.5">\${p}%</div>
          </div>
        \`;
      });
      document.getElementById('regionLegend').innerHTML = legHtml;
    }

    // 3. Category Horizontal Glowing Bar Chart
    function drawCategoryChart() {
      const setup = setupCanvas('categoryChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const catTotals = {};
      filteredOrders.forEach(o => {
        catTotals[o[3]] = (catTotals[o[3]] || 0) + o[9];
      });

      const sorted = Object.entries(catTotals).sort((a,b) => b[1] - a[1]);
      if (sorted.length === 0) return;

      const maxVal = Math.max(...sorted.map(s => s[1]), 1);
      const totalRev = sorted.reduce((a,b)=>a+b[1], 0) || 1;

      const padL = 130, padR = 80, padT = 20, padB = 20;
      const chartW = width - padL - padR;
      const count = sorted.length;
      const rowH = (height - padT - padB) / count;
      const barH = Math.min(rowH * 0.55, 20);

      const colors = [
        ['#FF9900', '#FFA41C', 'rgba(255,153,0,0.4)'],
        ['#00E5FF', '#00B4D8', 'rgba(0,229,255,0.4)'],
        ['#A855F7', '#C084FC', 'rgba(168,85,247,0.4)'],
        ['#10B981', '#34D399', 'rgba(16,185,129,0.4)'],
        ['#F43F5E', '#FB7185', 'rgba(244,63,94,0.4)'],
        ['#3B82F6', '#60A5FA', 'rgba(59,130,246,0.4)']
      ];

      sorted.forEach(([cat, val], idx) => {
        const y = padT + idx * rowH + (rowH - barH) / 2;
        const bW = (val / maxVal) * chartW;
        const col = colors[idx % colors.length];

        // Label
        ctx.save();
        ctx.fillStyle = '#E2E8F0';
        ctx.font = '11px "Plus Jakarta Sans"';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillText(cat, padL - 12, y + barH / 2);
        ctx.restore();

        // Bar Track
        ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.beginPath();
        ctx.roundRect(padL, y, chartW, barH, 4);
        ctx.fill();

        // Gradient Bar with Glow
        ctx.save();
        const grad = ctx.createLinearGradient(padL, 0, padL + bW, 0);
        grad.addColorStop(0, col[0]);
        grad.addColorStop(1, col[1]);

        ctx.fillStyle = grad;
        ctx.shadowColor = col[2];
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.roundRect(padL, y, Math.max(bW, 4), barH, 4);
        ctx.fill();
        ctx.restore();

        // Value text
        ctx.save();
        ctx.fillStyle = '#94A3B8';
        ctx.font = 'bold 11px "Outfit"';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        const pct = ((val / totalRev) * 100).toFixed(1);
        ctx.fillText(formatINR(val, true) + ' (' + pct + '%)', padL + bW + 8, y + barH / 2);
        ctx.restore();
      });
    }

    // 4. Payment Methods Chart (Glowing Horizontal/Vertical Stack)
    function drawPaymentChart() {
      const setup = setupCanvas('paymentChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const payTotals = {};
      filteredOrders.forEach(o => {
        payTotals[o[10]] = (payTotals[o[10]] || 0) + o[9];
      });

      const sorted = Object.entries(payTotals).sort((a,b) => b[1] - a[1]);
      if (sorted.length === 0) return;

      const padL = 40, padR = 20, padT = 20, padB = 40;
      const chartW = width - padL - padR;
      const chartH = height - padT - padB;
      const maxVal = Math.max(...sorted.map(s => s[1]), 1);

      const stepX = chartW / sorted.length;
      const barW = Math.min(stepX * 0.5, 36);

      const payPalette = [
        ['#10B981', 'rgba(16,185,129,0.4)'],
        ['#3B82F6', 'rgba(59,130,246,0.4)'],
        ['#A855F7', 'rgba(168,85,247,0.4)'],
        ['#FF9900', 'rgba(255,153,0,0.4)'],
        ['#F43F5E', 'rgba(244,63,94,0.4)'],
        ['#00E5FF', 'rgba(0,229,255,0.4)']
      ];

      sorted.forEach(([pm, val], idx) => {
        const x = padL + idx * stepX + stepX / 2;
        const barH = (val / maxVal) * chartH;
        const y = padT + chartH - barH;
        const col = payPalette[idx % payPalette.length];

        ctx.save();
        const grad = ctx.createLinearGradient(0, y, 0, padT + chartH);
        grad.addColorStop(0, col[0]);
        grad.addColorStop(1, 'rgba(0,0,0,0.2)');

        ctx.fillStyle = grad;
        ctx.shadowColor = col[1];
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.roundRect(x - barW / 2, y, barW, barH, [4, 4, 0, 0]);
        ctx.fill();
        ctx.restore();

        // Amount label above bar
        ctx.save();
        ctx.fillStyle = '#CBD5E1';
        ctx.font = '10px "Plus Jakarta Sans"';
        ctx.textAlign = 'center';
        ctx.fillText(formatINR(val, true), x, y - 6);

        // Name below bar
        ctx.fillStyle = '#94A3B8';
        ctx.font = '10.5px "Plus Jakarta Sans"';
        const displayLabel = pm.length > 8 ? pm.substring(0, 7) + '..' : pm;
        ctx.fillText(displayLabel, x, height - 15);
        ctx.restore();
      });
    }

    // 5. Top 8 Products Chart (Horizontal Ranked Gradient Bars)
    function drawTopProductsChart() {
      const setup = setupCanvas('topProductsChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const prodMap = {};
      filteredOrders.forEach(o => {
        if (!prodMap[o[2]]) prodMap[o[2]] = { name: o[2], cat: o[3], sales: 0, qty: 0 };
        prodMap[o[2]].sales += o[9];
        prodMap[o[2]].qty += o[5];
      });

      const sorted = Object.values(prodMap).sort((a,b) => b.sales - a.sales).slice(0, 8);
      if (sorted.length === 0) return;

      const maxVal = Math.max(...sorted.map(s => s.sales), 1);
      const padL = 175, padR = 85, padT = 20, padB = 20;
      const chartW = width - padL - padR;
      const count = sorted.length;
      const rowH = (height - padT - padB) / count;
      const barH = Math.min(rowH * 0.52, 18);

      sorted.forEach((p, idx) => {
        const y = padT + idx * rowH + (rowH - barH) / 2;
        const bW = (p.sales / maxVal) * chartW;

        // Label
        ctx.save();
        ctx.fillStyle = '#FFFFFF';
        ctx.font = '11px "Plus Jakarta Sans"';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        const name = p.name.length > 21 ? p.name.substring(0, 19) + '..' : p.name;
        ctx.fillText(\`#\${idx+1} \${name}\`, padL - 12, y + barH / 2);
        ctx.restore();

        // Track
        ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.beginPath();
        ctx.roundRect(padL, y, chartW, barH, 4);
        ctx.fill();

        // Gradient Bar with Amber Glow
        ctx.save();
        const grad = ctx.createLinearGradient(padL, 0, padL + bW, 0);
        grad.addColorStop(0, '#FFB84D');
        grad.addColorStop(1, '#FF7700');

        ctx.fillStyle = grad;
        ctx.shadowColor = 'rgba(255, 153, 0, 0.4)';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.roundRect(padL, y, Math.max(bW, 4), barH, 4);
        ctx.fill();
        ctx.restore();

        // Value text
        ctx.save();
        ctx.fillStyle = '#E2E8F0';
        ctx.font = 'bold 11px "Outfit"';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(formatINR(p.sales, true) + ' (' + p.qty + 'u)', padL + bW + 8, y + barH / 2);
        ctx.restore();
      });
    }

    // 6. Delivery SLA Chart (Stacked On-Time vs Late by Region)
    function drawDeliverySlaChart() {
      const setup = setupCanvas('deliverySlaChart');
      if (!setup) return;
      const { ctx, width, height } = setup;
      ctx.clearRect(0, 0, width, height);

      const regKeys = ['North', 'South', 'West', 'East', 'Central'];
      const onTime = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };
      const delayed = { 'North': 0, 'South': 0, 'West': 0, 'East': 0, 'Central': 0 };

      filteredOrders.forEach(o => {
        if (o[11] === 'Delivered') {
          if (o[16] > 0) {
            if (delayed[o[12]] !== undefined) delayed[o[12]] += 1;
          } else {
            if (onTime[o[12]] !== undefined) onTime[o[12]] += 1;
          }
        }
      });

      const maxTotal = Math.max(...regKeys.map(k => onTime[k] + delayed[k]), 50);

      const padL = 40, padR = 20, padT = 20, padB = 40;
      const chartW = width - padL - padR;
      const chartH = height - padT - padB;
      const stepX = chartW / regKeys.length;
      const barW = Math.min(stepX * 0.45, 34);

      // Draw grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        const y = padT + (chartH / 4) * i;
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(width - padR, y);
        ctx.stroke();
      }

      regKeys.forEach((k, idx) => {
        const x = padL + idx * stepX + stepX / 2;
        const otVal = onTime[k];
        const dlVal = delayed[k];
        const tot = otVal + dlVal;

        const otH = (otVal / maxTotal) * chartH;
        const dlH = (dlVal / maxTotal) * chartH;

        const yBase = padT + chartH;
        const yOt = yBase - otH;
        const yDl = yOt - dlH;

        // Bottom segment: On-Time (Emerald)
        ctx.save();
        ctx.fillStyle = '#10B981';
        ctx.shadowColor = 'rgba(16, 185, 129, 0.35)';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.roundRect(x - barW / 2, yOt, barW, otH, [0, 0, 4, 4]);
        ctx.fill();
        ctx.restore();

        // Top segment: Delayed (Rose)
        ctx.save();
        ctx.fillStyle = '#F43F5E';
        ctx.shadowColor = 'rgba(244, 63, 94, 0.35)';
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.roundRect(x - barW / 2, yDl, barW, dlH, [4, 4, 0, 0]);
        ctx.fill();
        ctx.restore();

        // On-time % label
        ctx.save();
        const pct = tot > 0 ? Math.round((otVal / tot) * 100) : 0;
        ctx.fillStyle = '#E2E8F0';
        ctx.font = 'bold 10px "Plus Jakarta Sans"';
        ctx.textAlign = 'center';
        ctx.fillText(pct + '% OT', x, yDl - 6);

        // Region label
        ctx.fillStyle = '#94A3B8';
        ctx.font = '11px "Plus Jakarta Sans"';
        ctx.fillText(k, x, height - 15);
        ctx.restore();
      });
    }

    // ==========================================
    // DATA TABLE CONTROLLER & PAGINATION
    // ==========================================

    function sortTable(colIdx) {
      if (currentSortCol === colIdx) {
        currentSortAsc = !currentSortAsc;
      } else {
        currentSortCol = colIdx;
        currentSortAsc = true;
      }

      filteredOrders.sort((a, b) => {
        let vA = a[colIdx];
        let vB = b[colIdx];

        if (typeof vA === 'string') {
          return currentSortAsc ? vA.localeCompare(vB) : vB.localeCompare(vA);
        }
        return currentSortAsc ? (vA - vB) : (vB - vA);
      });

      renderTable();
    }

    function changePageSize(size) {
      pageSize = parseInt(size);
      currentPage = 1;
      renderTable();
    }

    function prevPage() {
      if (currentPage > 1) {
        currentPage--;
        renderTable();
      }
    }

    function nextPage() {
      const maxPage = Math.ceil(filteredOrders.length / pageSize);
      if (currentPage < maxPage) {
        currentPage++;
        renderTable();
      }
    }

    function renderTable() {
      const tbody = document.getElementById('ordersTableBody');
      const total = filteredOrders.length;
      const maxPage = Math.max(1, Math.ceil(total / pageSize));
      if (currentPage > maxPage) currentPage = maxPage;

      document.getElementById('currentPageNum').textContent = currentPage;
      document.getElementById('totalPageNum').textContent = maxPage;
      document.getElementById('prevBtn').disabled = (currentPage === 1);
      document.getElementById('nextBtn').disabled = (currentPage === maxPage || total === 0);

      const start = (currentPage - 1) * pageSize;
      const end = Math.min(start + pageSize, total);

      document.getElementById('tableCountBadge').textContent = total > 0 
        ? \`Showing \${start + 1}-\${end} of \${total.toLocaleString()}\` 
        : 'No records';

      if (total === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="p-8 text-center text-slate-400 font-medium">No transactions match current filters.</td></tr>';
        return;
      }

      const paged = filteredOrders.slice(start, end);
      let html = '';

      paged.forEach((o, i) => {
        const globalIdx = start + i;
        const statusColor = getStatusColor(o[11]);
        const isLate = o[16] > 0;

        html += \`
          <tr class="hover:bg-slate-800/70 transition group cursor-pointer" onclick="openOrderDetail(\${globalIdx})">
            <td class="p-3.5 font-mono font-semibold text-amber-400">\${o[0]}</td>
            <td class="p-3.5 text-slate-400 whitespace-nowrap">\${o[1]}</td>
            <td class="p-3.5">
              <div class="font-semibold text-white group-hover:text-amber-400 transition">\${o[2]}</div>
              <div class="text-[11px] text-slate-400">\${o[3]} • \${o[4]}</div>
            </td>
            <td class="p-3.5 text-center font-mono text-slate-200">\${o[5]}</td>
            <td class="p-3.5 text-right font-mono font-bold text-white">₹\${o[9].toLocaleString('en-IN')}</td>
            <td class="p-3.5 text-slate-300">\${o[10]}</td>
            <td class="p-3.5">
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold \${statusColor}">\${o[11]}</span>
            </td>
            <td class="p-3.5 text-slate-300">
              <div>\${o[13]}</div>
              <div class="text-[11px] text-slate-400">\${o[14]}, \${o[12]}</div>
            </td>
            <td class="p-3.5 text-center">
              \${o[15] >= 0 ? \`
                <span class="inline-flex items-center gap-1 text-xs font-semibold \${isLate ? 'text-rose-400' : 'text-emerald-400'}">
                  \${isLate ? '⚠️ +' + o[16] + 'd late' : '✓ ' + o[15] + 'd on-time'}
                </span>
              \` : '<span class="text-slate-500 font-mono">-</span>'}
            </td>
            <td class="p-3.5 text-center">
              <button onclick="event.stopPropagation(); openOrderDetail(\${globalIdx})" class="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-amber-500 hover:text-black text-slate-300 text-xs font-bold transition shadow-sm">
                View
              </button>
            </td>
          </tr>
        \`;
      });

      tbody.innerHTML = html;
    }

    function exportFilteredCSV() {
      if (filteredOrders.length === 0) {
        alert('No data to export.');
        return;
      }
      const headers = ['OrderID','OrderDate','ProductName','Category','Subcategory','Quantity','UnitPriceINR','DiscountINR','ShippingFeeINR','SalesINR','PaymentMethod','OrderStatus','Region','City','State','DeliveryDays','LateDays','Quarter','MonthNum','CustomerSegment','CustomerName'];
      let csv = headers.join(',') + '\\n';

      filteredOrders.forEach(row => {
        const escaped = row.map(val => {
          if (typeof val === 'string' && (val.includes(',') || val.includes('"') || val.includes('\\n'))) {
            return '"' + val.replace(/"/g, '""') + '"';
          }
          return val;
        });
        csv += escaped.join(',') + '\\n';
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', \`Amazon_Sales_Report_\${new Date().toISOString().split('T')[0]}.csv\`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    window.addEventListener('DOMContentLoaded', () => {
      updateUI();
    });

    window.addEventListener('resize', () => {
      renderAllCharts();
    });
  </script>
</body>
</html>`;

fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\amazon-sales-dashboard\\index.html', html, 'utf8');
fs.writeFileSync('C:\\Users\\PC\\.gemini\\antigravity\\scratch\\amazon_sales_dashboard.html', html, 'utf8');
console.log('Finished updating both dashboard files with native canvas glowing chart engine!');
